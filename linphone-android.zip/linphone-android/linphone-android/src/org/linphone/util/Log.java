package org.linphone.util;

public class Log {

	private static Boolean DEBUG_ON = Boolean.TRUE;

	// Use app settings to turn debug on or off.
	public static void setDebug(Boolean isOn) {
		DEBUG_ON = isOn;
	}
	
	public static void i(String... args) {
		if(!DEBUG_ON)return;
		TagAndMessage tm = getTagAndMessage(args);
		android.util.Log.i(tm.tag, tm.message);
	}
	
	public static void i(String tag, String message, Throwable e) {
		if(!DEBUG_ON)return;
		android.util.Log.i(tag, message, e);
	}
	
	public static void d(String... args) {
		if(!DEBUG_ON)return;
		TagAndMessage tm = getTagAndMessage(args);
		android.util.Log.d(tm.tag, tm.message);
	}
	
	public static void d(String tag, String message, Throwable e) {
		if(!DEBUG_ON)return;
		android.util.Log.d(tag, message, e);
	}

	public static void e(String... args) {
		if(!DEBUG_ON)return;
		TagAndMessage tm = getTagAndMessage(args);
		android.util.Log.e(tm.tag, tm.message);
	}
	
	public static void e(String message, Throwable e) {
		if(!DEBUG_ON)return;
		final StackTraceElement[] ste = Thread.currentThread().getStackTrace();
		String tag = buildTag(ste);
		android.util.Log.e(tag, message, e);
	}
	
	public static void e(String tag, String message, Throwable e) {
		if(!DEBUG_ON)return;
		android.util.Log.e(tag, message, e);
	}

	public static void w(String... args) {
		if(!DEBUG_ON)return;
		TagAndMessage tm = getTagAndMessage(args);
		android.util.Log.w(tm.tag, tm.message);
	}

	public static void w(String message, Throwable e) {
		if(!DEBUG_ON)return;
		final StackTraceElement[] ste = Thread.currentThread().getStackTrace();
		String tag = buildTag(ste);
		android.util.Log.w(tag, message, e);
	}

	public static void w(String tag, String message, Throwable e) {
		if(!DEBUG_ON)return;
		android.util.Log.w(tag, message, e);
	}

	public static void v(String... args) {
		if(!DEBUG_ON)return;
		TagAndMessage tm = getTagAndMessage(args);
		android.util.Log.v(tm.tag, tm.message);
	}
	
	public static void v(String tag, String message, Throwable e) {
		if(!DEBUG_ON)return;
		android.util.Log.v(tag, message, e);
	}
	
	public static void wtf(String... args) {
		if(!DEBUG_ON)return;
		TagAndMessage tm = getTagAndMessage(args);
		android.util.Log.wtf(tm.tag, tm.message);
	}
	
	public static void wtf(String tag, String message, Throwable e) {
		if(!DEBUG_ON)return;
		android.util.Log.v(tag, message, e);
	}
	
	private static String buildTag(StackTraceElement[] ste) {
		return getClassName(ste) + "." + getMethodName(ste) + "(" + getLineNumber(ste) + ")";
	}

//	private static String getClassPackage(StackTraceElement[] ste) {
//		return ste[4].getClassName();
//	}

	private static String getClassName(StackTraceElement[] ste) {
		String[] tokens = ste[4].getClassName().split("\\.");
		return tokens[tokens.length - 1];
	}

	private static String getMethodName(StackTraceElement[] ste) {
		return ste[4].getMethodName();
	}

	private static int getLineNumber(StackTraceElement[] ste) {
		return ste[4].getLineNumber();
	}
	
	private static TagAndMessage getTagAndMessage(String... args){
		final StackTraceElement[] ste = Thread.currentThread().getStackTrace();
		String tag = null;
		String message = null;
		if(args.length == 1){
			tag = buildTag(ste);
			message = args[0];
		}
		if(args.length == 2){
			tag = args[0];
			message = args[1];
		}
		return (tag==null || message==null) ? null : new TagAndMessage(tag,message);
	}
}

class TagAndMessage{
	String tag;
	String message;
	TagAndMessage(String tag,String message){
		this.tag = tag;
		this.message = message;
	}
}
