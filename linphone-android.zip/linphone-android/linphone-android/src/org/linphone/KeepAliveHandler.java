package org.linphone;
import org.linphone.mediastream.Log;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class KeepAliveHandler extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		
		}
}
