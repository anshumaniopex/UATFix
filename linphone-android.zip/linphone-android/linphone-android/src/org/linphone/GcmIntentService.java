package org.linphone;

import com.google.android.gms.gcm.GoogleCloudMessaging;

import android.app.IntentService;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import org.linphone.util.Log;

/**
 * This {@code IntentService} does the actual handling of the GCM message.
 * {@code GcmBroadcastReceiver} (a {@code WakefulBroadcastReceiver}) holds a
 * partial wake lock for this service while the service does its work. When the
 * service is finished, it calls {@code completeWakefulIntent()} to release the
 * wake lock.
 */
public class GcmIntentService extends IntentService{

	public static final int NOTIFICATION_ID = 1;
	private NotificationManager mNotificationManager;
	NotificationCompat.Builder builder;

	public GcmIntentService(){
		super("GcmIntentService");
	}

	public static final String RECEIVED_PUSH_NOTIFICATION = "org.linphone.RECEIVED_PUSH_NOTIFICATION";

	@Override
	protected void onHandleIntent(Intent intent){

		Bundle extras 			 = intent.getExtras();
		GoogleCloudMessaging gcm = GoogleCloudMessaging.getInstance(this);
		String messageType       = gcm.getMessageType(intent);

		if(!extras.isEmpty()){  // has effect of un-parcelling Bundle

			/*
             * Filter messages based on message type. Since it is likely that GCM
             * will be extended in the future with new message types, just ignore
             * any message types you're not interested in, or that you don't
             * recognize.
             */
			if (GoogleCloudMessaging.MESSAGE_TYPE_SEND_ERROR.equals(messageType)) {
				sendNotification("Send error: " + extras.toString());
			}
			else if (GoogleCloudMessaging.MESSAGE_TYPE_DELETED.equals(messageType)) {
				sendNotification("Deleted messages on server: " + extras.toString());

			}
			else if (GoogleCloudMessaging.MESSAGE_TYPE_MESSAGE.equals(messageType)) {

				Log.i("body -> "+extras.getString("body"));
				Log.i("caller_id -> "+extras.getString("caller_id"));
				Log.i("collapse_key -> "+extras.getString("collapse_key"));
				Log.i("time_stamp -> "+extras.getString("time_stamp"));
				Log.i("msg_type -> "+extras.getString("msg_type"));

				broadcastPushNotificationReceived(extras);
			}
			// Release the wake lock provided by the WakefulBroadcastReceiver.
			GcmBroadcastReceiver.completeWakefulIntent(intent);
		}
	}

	/**
	 * Send broadcast to the MainActivity with the payload contents.
	 * @param extras
	 */
	private void broadcastPushNotificationReceived(Bundle extras){

		String body = extras.getString("body");
		String caller_id = extras.getString("caller_id");
		String collapse_key = extras.getString("collapse_key");
		String timeStamp = extras.getString("time_stamp");
		String msg_type = extras.getString("msg_type");

		Log.i("body -> "+body);
		Log.i("caller_id -> "+caller_id);
		Log.i("collapse_key -> "+collapse_key);
		Log.i("time_stamp -> "+timeStamp);
		Log.i("msg_type -> "+msg_type);

		Intent i = new Intent(RECEIVED_PUSH_NOTIFICATION);
		i.putExtra("body", body);
		i.putExtra("caller_id", caller_id);
		i.putExtra("collapse_key", collapse_key);
		i.putExtra("time_stamp", timeStamp);
		i.putExtra("msg_type", msg_type);
		GcmIntentService.this.sendBroadcast(i);
	}

	/**
	 * Put the message into a notification and post it.
 	 */
	private void sendNotification(String msg){

		mNotificationManager = (NotificationManager) this.getSystemService(Context.NOTIFICATION_SERVICE);

		PendingIntent contentIntent = PendingIntent.getActivity(this, 0, new Intent(this, LinphoneActivity.class), 0);

		NotificationCompat.Builder mBuilder =
				new NotificationCompat.Builder(this)
						.setSmallIcon(R.drawable.ic_stat_gcm)
						.setContentTitle("Push Notification")
						.setStyle(new NotificationCompat.BigTextStyle().bigText(msg)).setContentText(msg);

		mBuilder.setContentIntent(contentIntent);
		mNotificationManager.notify(NOTIFICATION_ID, mBuilder.build());
	}
}
