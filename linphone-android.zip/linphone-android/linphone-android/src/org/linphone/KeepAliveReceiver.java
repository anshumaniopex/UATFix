package org.linphone;

import org.linphone.mediastream.Log;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/*
 * Purpose of this receiver is to disable keep alives when screen is off
 * */
public class KeepAliveReceiver extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		
		if (!LinphoneService.isReady()) {
			Log.i("Keep alive broadcast received while Linphone service not ready");
			return;
		} else {
			if (intent.getAction().equalsIgnoreCase(Intent.ACTION_SCREEN_ON)) {
				LinphoneManager.getLc().enableKeepAlive(true);
			} else if (intent.getAction().equalsIgnoreCase(Intent.ACTION_SCREEN_OFF)) {
				LinphoneManager.getLc().enableKeepAlive(false);
			}
		}

	}

}
