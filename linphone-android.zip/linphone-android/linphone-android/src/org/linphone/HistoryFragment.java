package org.linphone;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.linphone.core.CallDirection;
import org.linphone.core.LinphoneAddress;
import org.linphone.core.LinphoneCallLog;
import org.linphone.core.LinphoneCoreException;
import org.linphone.core.LinphoneCoreFactory;
import org.linphone.core.LinphoneProxyConfig;
import org.linphone.core.LinphoneCallLog.CallStatus;
import org.linphone.ui.AvatarWithShadow;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.ExpandableListView.OnGroupClickListener;
import android.widget.ImageView;
import android.widget.TextView;


public class HistoryFragment extends Fragment implements OnClickListener, OnChildClickListener, OnGroupClickListener {
	private Handler mHandler = new Handler();
	private ExpandableListView historyList;
	private LayoutInflater mInflater;
	private RelativeLayout fkeypad;
	private ImageView FKeyPad,FDelete,FCancel,FDeleteSetting;
	
	private OnClickListener fkeypadListener;
	private Context cxt;
	private TextView allCalls, missedCalls, edit, ok, deleteAll, noMissedCallHistory;//, noCallHistory
	private boolean onlyDisplayMissedCalls, isEditMode;
	private SparseArray<List<LinphoneCallLog>> mLogs; 
	
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, 
        Bundle savedInstanceState) {
		mInflater = inflater;
        View view = inflater.inflate(R.layout.history, container, false);
        
        
        cxt=inflater.getContext();
        
      
       fkeypad=(RelativeLayout)view.findViewById(R.id.fkeypad);
        fkeypadListener = new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (LinphoneActivity.isInstanciated()) {
					LinphoneActivity.instance().changeCurrentFragmentans(FragmentsAvailable.DIALER, null);
				}
			}
		};
		fkeypad.setOnClickListener(fkeypadListener);

        noMissedCallHistory = (TextView) view.findViewById(R.id.noMissedCallHistory);
        
        historyList = (ExpandableListView) view.findViewById(R.id.historyList);
        historyList.setOnChildClickListener(this);
        historyList.setOnGroupClickListener(this);
        
       
        FDelete = (ImageView) view.findViewById(R.id.hdelete);
        FDelete.setOnClickListener(this);
        FDeleteSetting =(ImageView) view.findViewById(R.id.hdeleteSetting);
        FDeleteSetting.setOnClickListener(this);
    
        
        deleteAll = (TextView) view.findViewById(R.id.deleteAll);
        deleteAll.setOnClickListener(this);
        deleteAll.setVisibility(View.INVISIBLE);
        
        allCalls = (TextView) view.findViewById(R.id.allCalls);
        allCalls.setOnClickListener(this);
        
        missedCalls = (TextView) view.findViewById(R.id.missedCalls);
        missedCalls.setOnClickListener(this);
        
        allCalls.setEnabled(false);
        onlyDisplayMissedCalls = false;
        
        edit = (TextView) view.findViewById(R.id.edit);
        edit.setOnClickListener(this);
        
        ok = (TextView) view.findViewById(R.id.ok);
        ok.setOnClickListener(this);
        
		return view;
    }
	
	private boolean hideHistoryListAndDisplayMessageIfEmpty() {
		if (mLogs.size() == 0) {
			if (onlyDisplayMissedCalls) {
				noMissedCallHistory.setVisibility(View.VISIBLE);
			} else {
				}
			historyList.setVisibility(View.GONE);
			return true;
		} else {
			noMissedCallHistory.setVisibility(View.GONE);
			historyList.setVisibility(View.VISIBLE);
			return false;
		}
	}
	
	@Override
	public void onResume() {
		super.onResume();
		if (LinphoneActivity.isInstanciated())
			LinphoneActivity.instance().selectMenu(FragmentsAvailable.HISTORY);
		
		initLogsLists(Arrays.asList(LinphoneManager.getLc().getCallLogs()));
		if (!hideHistoryListAndDisplayMessageIfEmpty()) {
			historyList.setAdapter(new CallHistoryAdapter(getActivity().getApplicationContext()));
		}
     }
	
	
	
	
	private void initLogsLists(List<LinphoneCallLog> logs) {
		mLogs = new SparseArray<List<LinphoneCallLog>>(); 
		String[] keys = new String[logs.size()];
		for (LinphoneCallLog log : logs) {
			String groupBy = getCorrespondentDisplayName(log);
			int key = -1;
			for (int k = 0; k < keys.length; k++) {
				if (keys[k] == null || keys[k].equals(groupBy)) {
					key = k;
					keys[k] = groupBy;
					break;
				}
			}
			
			List<LinphoneCallLog> group = mLogs.get(key, new ArrayList<LinphoneCallLog>());
			group.add(log);
			if (group.size() == 1) {
				mLogs.append(key, group);
			}
		}
	}
	
	private void initMissedLogsLists(List<LinphoneCallLog> logs) {
		List<LinphoneCallLog> missedLogs = new ArrayList<LinphoneCallLog>();
		for (LinphoneCallLog log : logs) {
			if (log.getDirection() == CallDirection.Incoming && log.getStatus() == CallStatus.Missed) {
				missedLogs.add(log);
			}
		}
		initLogsLists(missedLogs);
	}
	
	private void expandAllGroups() {
		mHandler.post(new Runnable() {
			@Override
			public void run() {
				for (int groupToExpand = 0; groupToExpand < historyList.getExpandableListAdapter().getGroupCount(); groupToExpand++) {
					if (!historyList.isGroupExpanded(groupToExpand)) {
						historyList.expandGroup(groupToExpand);
					}
				}
			}
		});
	}

	
	
	private String getCorrespondentDisplayName(LinphoneCallLog log) {
		String displayName;
		LinphoneAddress address;
		if (log.getDirection() == CallDirection.Incoming) {
			address = log.getFrom();
		} else {
			address = log.getTo();
		}
		
		LinphoneUtils.findUriPictureOfContactAndSetDisplayName(address, getActivity().getContentResolver());
		String sipUri = address.asStringUriOnly();
		displayName = address.getDisplayName(); 
		
		if (displayName == null) {
			if (getResources().getBoolean(R.bool.only_display_username_if_unknown) && LinphoneUtils.isSipAddress(sipUri)) {
				displayName = LinphoneUtils.getUsernameFromAddress(sipUri);
			} else {
				displayName = sipUri;
			}
		}
		
		return displayName;
	}

	@Override
	public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
		super.onCreateContextMenu(menu, v, menuInfo);
		menu.add(0, v.getId(), 0, getString(R.string.delete));
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		
		if (id == R.id.allCalls) {
			allCalls.setEnabled(false);
			missedCalls.setEnabled(true);
			onlyDisplayMissedCalls = false;
			
			initLogsLists(Arrays.asList(LinphoneManager.getLc().getCallLogs()));
		} 
		else if (id == R.id.missedCalls) {
			allCalls.setEnabled(true);
			missedCalls.setEnabled(false);
			onlyDisplayMissedCalls = true;
			
			initMissedLogsLists(Arrays.asList(LinphoneManager.getLc().getCallLogs()));
		} 
		else if (id == R.id.ok) {
			edit.setVisibility(View.VISIBLE);
			ok.setVisibility(View.GONE);
			hideDeleteAllButton();
			isEditMode = false;
		} 
		else if (id == R.id.edit) {
			edit.setVisibility(View.GONE);
			ok.setVisibility(View.VISIBLE);
			showDeleteAllButton();
			isEditMode = true;
		}
		else if (id == R.id.deleteAll) {
			 LinphoneManager.getLc().clearCallLogs();
			 initLogsLists(new ArrayList<LinphoneCallLog>());
		}else if(id ==R.id.hdelete){
			Log.i("-----Anshuman-------------","========hdelete clicked=====================");
			LinphoneManager.getLc().clearCallLogs();
			initLogsLists(new ArrayList<LinphoneCallLog>());
		}else if(id ==R.id.hdeleteSetting){
			Log.i("-----Anshuman-------------","========hdelete Setting  clicked=====================");
			initiateMessageWindow(v);
		}
		if (!hideHistoryListAndDisplayMessageIfEmpty()) {
			historyList.setAdapter(new CallHistoryAdapter(getActivity().getApplicationContext()));
		}
	
	}

	private void initiateMessageWindow(View v) {
		LayoutInflater inflater = (LayoutInflater)v.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View layout = inflater.inflate(R.layout.popupitem, null);
		final AlertDialog deleteDialog = new AlertDialog.Builder(
				v.getContext()).create();
	    deleteDialog.setView(layout);
	    WindowManager.LayoutParams wmlp = deleteDialog.getWindow().getAttributes();
	    wmlp.gravity = Gravity.BOTTOM | Gravity.RIGHT;
	    deleteDialog.getWindow().setLayout(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT);
	    deleteDialog.show();
	    WindowManager.LayoutParams lp = new WindowManager.LayoutParams();

	    lp.copyFrom(deleteDialog.getWindow().getAttributes());
	    lp.width = 300;
	    deleteDialog.getWindow().setAttributes(lp);
	    TextView tvSetting=(TextView)layout.findViewById(R.id.Setting);
	    tvSetting.setOnClickListener(new OnClickListener() {
			@Override
	        public void onClick(View v) {
				deleteDialog.dismiss();
				if (LinphoneActivity.isInstanciated()) {
					LinphoneActivity.instance().changeCurrentFragmentans(FragmentsAvailable.SETTINGS, null);
				}
	        }
	    });
		TextView tvDelete=(TextView)layout.findViewById(R.id.delete);
		tvDelete.setText("Clear Log");
		tvDelete.setOnClickListener(new OnClickListener() {
			@Override
	        public void onClick(View v) {
			deleteDialog.dismiss();
				deletelog();
			}
	    });
		
}
	
	public void deletelog(){
		LinphoneManager.getLc().clearCallLogs();
		initLogsLists(new ArrayList<LinphoneCallLog>());
		if (!hideHistoryListAndDisplayMessageIfEmpty()) {
			historyList.setAdapter(new CallHistoryAdapter(getActivity().getApplicationContext()));
		}
	}
	
	
	@Override
	public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
		if (isEditMode) {
			for (LinphoneCallLog log : mLogs.get(groupPosition)) {
				LinphoneManager.getLc().removeCallLog(log);
			}
	
		}

		LinphoneCallLog log = mLogs.get(groupPosition).get(0);
		LinphoneAddress address;
		if (log.getDirection() == CallDirection.Incoming) {
			address = log.getFrom();
		} else {
			address = log.getTo();
		}
		if (LinphoneActivity.isInstanciated()) {
			//LinphoneActivity.instance().displayHistoryDetail(address.asStringUriOnly(), log);
			String DisplayName=getCorrespondentDisplayName(log);
		    if(DisplayName!=null)
			LinphoneActivity.instance().newdisplayHistoryDetail(DisplayName);
		    
		}
		return true;
	}

	@Override
	public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
		LinphoneCallLog log = mLogs.get(groupPosition).get(childPosition);
		if (isEditMode) {
			LinphoneManager.getLc().removeCallLog(log);
			initLogsLists(Arrays.asList(LinphoneManager.getLc().getCallLogs()));
			if (!hideHistoryListAndDisplayMessageIfEmpty()) {
				historyList.setAdapter(new CallHistoryAdapter(getActivity().getApplicationContext()));
			}
	        expandAllGroups();
		} else {
			LinphoneAddress address;
			if (log.getDirection() == CallDirection.Incoming) {
				address = log.getFrom();
			} else {
				address = log.getTo();
			}
			LinphoneActivity.instance().setAddresGoToDialerAndCall(address.asStringUriOnly(), address.getDisplayName(), null);
		}
		return false;
	}
	
	private void hideDeleteAllButton() {
		if (deleteAll == null || deleteAll.getVisibility() != View.VISIBLE) {
			return;
		}
			
		if (LinphoneActivity.instance().isAnimationDisabled()) {
			deleteAll.setVisibility(View.INVISIBLE);
		} else {
			Animation animation = AnimationUtils.loadAnimation(getActivity(), R.anim.slide_out_right_to_left);
			animation.setAnimationListener(new AnimationListener() {
				@Override
				public void onAnimationStart(Animation animation) {
					
				}
				
				@Override
				public void onAnimationRepeat(Animation animation) {
					
				}
				
				@Override
				public void onAnimationEnd(Animation animation) {
					deleteAll.setVisibility(View.INVISIBLE);
					animation.setAnimationListener(null);
				}
			});
			deleteAll.startAnimation(animation);
		}
	}
	
	private void showDeleteAllButton() {
		if (deleteAll == null || deleteAll.getVisibility() == View.VISIBLE) {
			return;
		}
		
		if (LinphoneActivity.instance().isAnimationDisabled()) {
			deleteAll.setVisibility(View.VISIBLE);
		} else {
			Animation animation = AnimationUtils.loadAnimation(getActivity(), R.anim.slide_in_left_to_right);
			animation.setAnimationListener(new AnimationListener() {
				@Override
				public void onAnimationStart(Animation animation) {
					
				}
				
				@Override
				public void onAnimationRepeat(Animation animation) {
					
				}
				
				@Override
				public void onAnimationEnd(Animation animation) {
					deleteAll.setVisibility(View.VISIBLE);
					animation.setAnimationListener(null);
				}
			});
			deleteAll.startAnimation(animation);
		}
	}
	
	class CallHistoryAdapter extends BaseExpandableListAdapter {
		private Bitmap missedCall, outgoingCall, incomingCall;
		
		CallHistoryAdapter(Context aContext) {
			missedCall = BitmapFactory.decodeResource(getResources(), R.drawable.call_status_missed);
			
			if (!onlyDisplayMissedCalls) {
				outgoingCall = BitmapFactory.decodeResource(getResources(), R.drawable.call_status_outgoing);
				incomingCall = BitmapFactory.decodeResource(getResources(), R.drawable.call_status_incoming);
			}
		}
		
		@Override
		public Object getChild(int groupPosition, int childPosition) {
			return mLogs.get(groupPosition).get(childPosition);
		}
		
		@Override
		public long getChildId(int groupPosition, int childPosition) {
			return childPosition;
		}
		
		@Override
		public View getChildView(int groupPosition, int childPosition,
				boolean isLastChild, View convertView, ViewGroup parent) {
			View view = null;
			if (convertView != null) {
				view = convertView;
			} else {
				view = mInflater.inflate(R.layout.history_cell, parent,false);
		}
			
			final LinphoneCallLog log = (LinphoneCallLog) getChild(groupPosition, childPosition);
			final LinphoneAddress address;
			
			TextView dateAndTime = (TextView) view.findViewById(R.id.dateAndTime);
			ImageView detail = (ImageView) view.findViewById(R.id.detail);
			ImageView delete = (ImageView) view.findViewById(R.id.delete);
			ImageView callDirection = (ImageView) view.findViewById(R.id.icon);
			
			
			if (log.getDirection() == CallDirection.Incoming) {
				address = log.getFrom();
				if (log.getStatus() == CallStatus.Missed) {
					callDirection.setImageBitmap(missedCall);
				} else {
					callDirection.setImageBitmap(incomingCall);
				}
			} else {
				address = log.getTo();
				callDirection.setImageBitmap(outgoingCall);
			}
			
			LinphoneUtils.findUriPictureOfContactAndSetDisplayName(address, view.getContext().getContentResolver());
			String sipUri = address.asStringUriOnly();
			dateAndTime.setText(log.getStartDate() + " " + log.getCallDuration());
			view.setTag(sipUri);
			return view;
		}
		
		@Override
		public int getChildrenCount(int groupPosition) {
			return mLogs.get(groupPosition).size();
		}
		
		@Override
		public Object getGroup(int groupPosition) {
			return mLogs.get(groupPosition);
		}
		
		@Override
		public int getGroupCount() {
			return mLogs.size();
		}
		
		@Override
		public long getGroupId(int groupPosition) {
			return groupPosition;
		}
		
		@Override
		public View getGroupView(int groupPosition, boolean isExpanded,
				View convertView, ViewGroup parent) {
			View view = null;
			if (convertView != null) {
				view = convertView;
			} else {
				view = mInflater.inflate(R.layout.fhistory_cell_simple, parent,false);
			}
			
			final LinphoneCallLog log = (LinphoneCallLog) getChild(groupPosition, 0);			
			final LinphoneAddress address;
			
			TextView contact = (TextView) view.findViewById(R.id.sipUri);
			ImageView delete = (ImageView) view.findViewById(R.id.delete);
			AvatarWithShadow contactPic=(AvatarWithShadow)view.findViewById(R.id.icon1);
			
			if (log.getDirection() == CallDirection.Incoming) {
				address = log.getFrom();
			} else {
				address = log.getTo();
			}
			Uri uri = LinphoneUtils.findUriPictureOfContactAndSetDisplayName(address, view.getContext().getContentResolver());
			String pictureUri = uri == null ? null : uri.toString();
			if (pictureUri != null) {
			LinphoneUtils.setImagePictureFromUri(view.getContext(), contactPic.getView(),		
			Uri.parse(pictureUri), R.drawable.ic_contact_picture_holo_dark);
			}else{
				contactPic.setImageResource(R.drawable.ic_contact_picture_holo_dark);
			}
		
			String displayName = getCorrespondentDisplayName(log);
			String sipUri = address.asStringUriOnly();
			Log.i("DisplayName","================"+displayName);
			contact.setText(displayName + " (" + getChildrenCount(groupPosition) + ")");
			if(Utilites.isInteger(displayName)){
				contact.setText(Utilites.setNumberFormat(displayName)+" (" + getChildrenCount(groupPosition) + ")");
					}
			view.setTag(sipUri);
			long timestamp = log.getTimestamp();
			Calendar logTime = Calendar.getInstance();
			logTime.setTimeInMillis(timestamp);
			TextView Number = (TextView) view.findViewById(R.id.Number);
			String str=Utilites.getNumberFromString(sipUri);
			if(!str.isEmpty()){
				Number.setText(Utilites.setNumberFormat(str.substring(1, str.length())));
				}
			else{
				Number.setText(displayName);	
				}	
			String sipUri1 = address.asStringUriOnly();
			String str1=Utilites.getNumberFromString(sipUri1);
			if(!str1.isEmpty()){
				if(Utilites.isInteger(str1) && str1.length()==11){
					LinphoneProxyConfig lpc = LinphoneManager.getLc().getDefaultProxyConfig();
					if (lpc != null) {
						String tag=Utilites.getNumberInLinphoneFormat(str1.substring(1,str1.length()));
						try {
							LinphoneAddress lAddress = LinphoneCoreFactory.instance().createLinphoneAddress(tag);
							uri =LinphoneUtils.findUriPictureOfContactAndSetDisplayName(lAddress, view.getContext().getContentResolver());
							Number.setText(Utilites.setNumberFormat(lAddress.getUserName()));
							pictureUri = uri == null ? null : uri.toString();
							if (pictureUri != null) {
							LinphoneUtils.setImagePictureFromUri(view.getContext(), contactPic.getView(),		
							Uri.parse(pictureUri), R.drawable.ic_contact_picture_holo_dark);
							}else{
								contactPic.setImageResource(R.drawable.ic_contact_picture_holo_dark);
							}
							//Log.i("DisplayName","=====||||||||||========="+lAddress.getDisplayName().substring(1, lAddress.getDisplayName().length()));
							if(lAddress.getDisplayName() == null){
							contact.setText(Utilites.setNumberFormat(lAddress.getUserName())+" (" + getChildrenCount(groupPosition) + ")");
							}else{
								contact.setText(lAddress.getDisplayName().substring(1, lAddress.getDisplayName().length()) + " (" + getChildrenCount(groupPosition) + ")");	
							}
						} catch (LinphoneCoreException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}
			
			LinearLayout l1=(LinearLayout)view.findViewById(R.id.log_iconlist);
			l1.removeAllViews();
			for(int i=0;i<getChildrenCount(groupPosition) && i<10;i++)
			{
				LinphoneCallLog log1 = (LinphoneCallLog) getChild(groupPosition,i);
				LinphoneAddress address1;
				ImageView child=new ImageView(cxt);
				if (log1.getDirection() == CallDirection.Incoming) {
					address1 = log1.getFrom();
					if (log1.getStatus() == CallStatus.Missed) {
						child.setImageBitmap(missedCall);
						l1.addView(child);
						} else {
						child.setImageBitmap(incomingCall);
						l1.addView(child);
					}
				} else {
					address1 = log1.getTo();
					child.setImageBitmap(outgoingCall);
					l1.addView(child);
				
				}
			}
			
			TextView t1=new TextView(cxt);
			t1.setText(Utilites.timestampToHumanDate(logTime));
			t1.setPadding(30,-2,0,0);
			l1.addView(t1);
			ImageView history_dial = (ImageView) view.findViewById(R.id.history_dial);
			history_dial.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					if (LinphoneActivity.isInstanciated()) {
						LinphoneActivity.instance().setAddresGoToDialerAndCall
						(address.asStringUriOnly(), address.getDisplayName(), null);
					}
				}
			});
		
			return view;
		}
		
		@Override
		public boolean hasStableIds() {
			return false;
		}
		
		@Override
		public boolean isChildSelectable(int groupPosition, int childPosition) {
			return true;
		}
	}
}
