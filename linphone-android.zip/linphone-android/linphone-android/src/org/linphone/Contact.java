package org.linphone;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.linphone.compatibility.Compatibility;
import org.linphone.core.LinphoneFriend;

import android.content.ContentResolver;
import android.graphics.Bitmap;
import android.net.Uri;

public class Contact implements Serializable {
	private static final long serialVersionUID = 3790717505065723499L;
	
	private String id;
	private String name;
	private transient Uri photoUri;
	private transient Bitmap photo;
	private List<String> numerosOrAddresses;
	private LinphoneFriend friend;
	
	public Contact(String id, String name) {
		super();
		this.id = id;
		this.name = name;
		this.photoUri = null;
		
	}
	
	public Contact(String id, String name, Uri photo) {
		super();
		this.id = id;
		this.name = name;
		this.photoUri = photo;
		this.photo = null;
	}
	
	public Contact(String id, String name, Uri photo, Bitmap picture) {
		super();
		this.id = id;
		this.name = name;
		this.photoUri = photo;
		this.photo = picture;
	}
	
	public void setFriend(LinphoneFriend friend) {
		this.friend = friend;
	}
	
	public LinphoneFriend getFriend() {
		return friend;
	}
	
	public String getID() {
		return id;
	}
	
	public String getName() {
		return name;
	}

	public Uri getPhotoUri() {
		return photoUri;
	}
	
	public Bitmap getPhoto() {
		return photo;
	}

	public List<String> getNumerosOrAddresses() {
		if (numerosOrAddresses == null)
			numerosOrAddresses = new ArrayList<String>();
		return numerosOrAddresses;
	}
	
	public void refresh(ContentResolver cr) {
		this.numerosOrAddresses = Compatibility.extractContactNumbersAndAddresses(id, cr);
		this.name = Compatibility.refreshContactName(cr, id);
	}
}
