package org.linphone;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.linphone.core.LinphoneProxyConfig;

public class Utilites {
	
	public static String tenNumberSupport(String Number){
		try {
			Number=getNumString(Number);
			if(Number.length()==10 && Utilites.isInteger(Number))
			{	Number=1+Number;}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return Number;
		}
		
		return Number;
	}

	public static boolean isInteger( String input )  
    {  
		
		String regex = "\\d+";
	   try  
       {  
    	return input.matches(regex);
       }  
       catch( Exception e)  
       {  
          return false;  
       }  
    }  
	
	
	public static String setNumberFormat(String Number){

		    Number = getNumString(Number);
			Number = Number.replaceAll("(\\d{3})(\\d{3})(\\d{4})", "($1) $2-$3");
		return Number;
	}

	public static String getNumberFromString(String address) {
		if (address.contains("sip:"))
		{	address = address.replace("sip:", "");
		}
		
		if (address.contains("@"))
			address = address.split("@")[0];
		
		return address;
	}
	
	
	public static String getNumberInLinphoneFormat(String Number){
		
		LinphoneProxyConfig lpc = LinphoneManager.getLc().getDefaultProxyConfig();
		String tag = Number;
		
		if (lpc != null) {
			if (!Number.startsWith("sip:")) {
				Number  = "sip:" + Number ;
			}
			
			if (!Number.contains("@")) {
				tag = Number+ "@" + lpc.getDomain();
			}
		} 
		 return tag;
	}
	
	
	
   public static String getNumString(String NumberString){
	   return NumberString.replaceAll("\\D+","");
   }
	
   public static String timestampToHumanDate(Calendar cal) {
		SimpleDateFormat dateFormat;
		if (isToday(cal)) {
			dateFormat = new SimpleDateFormat("HH:mm");
			return dateFormat.format(cal.getTime())+" "+"today";
		} else if (isYesterday(cal)) {
			dateFormat = new SimpleDateFormat("HH:mm d MMM");
		} else {
			dateFormat = new SimpleDateFormat("HH:mm d MMM");
		}
		
		return dateFormat.format(cal.getTime());
	}
   
 
   public static boolean isSameDay(Calendar cal1, Calendar cal2) {
       if (cal1 == null || cal2 == null) {
           return false;
       }
       
       return (cal1.get(Calendar.ERA) == cal2.get(Calendar.ERA) &&
               cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
               cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR));
   }
	
   public static boolean isToday(Calendar cal) {
       return isSameDay(cal, Calendar.getInstance());
   }
	
   public static boolean isYesterday(Calendar cal) {
		Calendar yesterday = Calendar.getInstance();
		yesterday.roll(Calendar.DAY_OF_MONTH, -1);
       return isSameDay(cal, yesterday);
   }
   
   
}
