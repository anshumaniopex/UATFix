package org.linphone;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import org.linphone.HistoryFragment.CallHistoryAdapter;
import org.linphone.core.CallDirection;
import org.linphone.core.LinphoneAddress;
import org.linphone.core.LinphoneCallLog;
import org.linphone.core.LinphoneCoreException;
import org.linphone.core.LinphoneCoreFactory;
import org.linphone.core.LinphoneCallLog.CallStatus;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class NewHistoryDetailFragment extends Fragment implements OnClickListener  {
	private ImageView dialBack, chat, addToContacts;
	private View view;
	private LayoutInflater mInflater;
	private TextView contactName, contactAddress, callDirection, time, date;
	private String sipUri, displayName, pictureUri;
	private String DisplayName;
	boolean ft=false;
	int n;
	private SparseArray<List<LinphoneCallLog>> mLogs; 
	private List<LinphoneCallLog> childlog;
	ListView L;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		mInflater=inflater;
		DisplayName =  getArguments().getString("DisplayName");
		view = inflater.inflate(R.layout.history_details1, container, false);
		
		L = (ListView) view.findViewById(R.id.hd1);
		L.setSelected(false);
		L.setClickable(false);
		
		contactName=(TextView) view.findViewById(R.id.contactDisplayName);
		contactAddress=(TextView)view.findViewById(R.id.contactAddress);
		
		contactName.setText(DisplayName.substring(1,DisplayName.length()));
		/*
		String str=Utilites.getNumberFromString(sipUri);
		if(!str.isEmpty()){
			contactAddress.setText(Utilites.setNumberFormat(str));}
		else{
			contactAddress.setText(displayName);	
			}
		
		*/
		
		return view;
	}
	
	
	private void getChildList(List<LinphoneCallLog> logs){
		childlog = new ArrayList<LinphoneCallLog>();
		for (LinphoneCallLog log : logs) {
			String groupBy = getCorrespondentDisplayName(log);
			if(DisplayName.equals(groupBy)){
				childlog.add(log);		
				}
		}
		//Log.i("","====================="+childlog.size());
	}
	
	private void initLogsLists(List<LinphoneCallLog> logs) {
		/*
		mLogs = new SparseArray<List<LinphoneCallLog>>(); 
		String[] keys = new String[logs.size()];
		for (LinphoneCallLog log : logs) {
			String groupBy = getCorrespondentDisplayName(log);
			int key = -1;
			for (int k = 0; k < keys.length; k++) {
				if (keys[k] == null || keys[k].equals(groupBy)) {
					key = k;
					keys[k] = groupBy;
					break;
				}
			}
			
			List<LinphoneCallLog> group = mLogs.get(key, new ArrayList<LinphoneCallLog>());
			group.add(log);
			if (group.size() == 1) {
				mLogs.append(key, group);
			}
		}
		*/
		getChildList(logs);
	}
	
	private String getCorrespondentDisplayName(LinphoneCallLog log) {
		String displayName;
		LinphoneAddress address;
		if (log.getDirection() == CallDirection.Incoming) {
			address = log.getFrom();
		} else {
			address = log.getTo();
		}
		
		LinphoneUtils.findUriPictureOfContactAndSetDisplayName(address, getActivity().getContentResolver());
		displayName = address.getDisplayName(); 
		String sipUri = address.asStringUriOnly();
		if (displayName == null) {
			if (getResources().getBoolean(R.bool.only_display_username_if_unknown) && LinphoneUtils.isSipAddress(sipUri)) {
				displayName = LinphoneUtils.getUsernameFromAddress(sipUri);
			} else {
				displayName = sipUri;
			}
		}
		
		return displayName;
	}

	
	
	
	
	@Override
	public void onResume() {
		super.onResume();
		if (LinphoneActivity.isInstanciated()) {
			LinphoneActivity.instance().selectMenu(FragmentsAvailable.HISTORY_DETAIL);
		}
		initLogsLists(Arrays.asList(LinphoneManager.getLc().getCallLogs()));
		L.setAdapter(new NewCallHistoryAdapter(getActivity().getApplicationContext()));
		
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		
		if (id == R.id.dialBack) {
			LinphoneActivity.instance().setAddresGoToDialerAndCall(sipUri, displayName, pictureUri == null ? null : Uri.parse(pictureUri));
		} else if (id == R.id.chat) {
			LinphoneActivity.instance().displayChat(sipUri);
		} else if (id == R.id.addToContacts) {
			String uriToAdd = sipUri;
			if (getResources().getBoolean(R.bool.never_display_sip_addresses)) {
				uriToAdd = LinphoneUtils.getUsernameFromAddress(sipUri);
			}
			LinphoneActivity.instance().displayContactsForEdition(uriToAdd);
		}
	}
	
	
	
	
	class NewCallHistoryAdapter extends  BaseAdapter {
		private Bitmap missedCall, outgoingCall, incomingCall;
		
		NewCallHistoryAdapter(Context aContext) {
			missedCall = BitmapFactory.decodeResource(getResources(), R.drawable.call_status_missed);
			outgoingCall = BitmapFactory.decodeResource(getResources(), R.drawable.call_status_outgoing);
			incomingCall = BitmapFactory.decodeResource(getResources(), R.drawable.call_status_incoming);
			
		}
		public int getCount() {
			return childlog.size();
		}

		public Object getItem(int position) {
			return childlog.get(position);
		}

		public long getItemId(int position) {
			return position;
		}
		
		@SuppressLint("SimpleDateFormat")
		private String timestampToHumanDate(Calendar cal) {
			SimpleDateFormat dateFormat;
			if (isToday(cal)) {
				return getString(R.string.today);
			} else if (isYesterday(cal)) {
				return getString(R.string.yesterday);
			} else {
				dateFormat = new SimpleDateFormat(getResources().getString(R.string.history_date_format));
			}
			
			return dateFormat.format(cal.getTime());
		}
		
		private boolean isSameDay(Calendar cal1, Calendar cal2) {
	        if (cal1 == null || cal2 == null) {
	            return false;
	        }
	        
	        return (cal1.get(Calendar.ERA) == cal2.get(Calendar.ERA) &&
	                cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
	                cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR));
	    }
		
		private boolean isToday(Calendar cal) {
	        return isSameDay(cal, Calendar.getInstance());
	    }
		
		private boolean isYesterday(Calendar cal) {
			Calendar yesterday = Calendar.getInstance();
			yesterday.roll(Calendar.DAY_OF_MONTH, -1);
	        return isSameDay(cal, yesterday);
	    }

		public View getView(int position, View convertView, ViewGroup parent) {
			View view = null;
			if (convertView != null) {
				view = convertView;
			} else {
				view = mInflater.inflate(R.layout.fhistory_detail_cell_simple, parent,false);
				//view = mInflater.inflate(R.layout.fhistory_cell_simple, parent,false);
			}
		//	Log.i("-----Anshuman-------------","====================ChildLog======================");
			
			final LinphoneCallLog log = childlog.get(position);
			long timestamp = log.getTimestamp();
			final LinphoneAddress address;
			
			TextView icondetails = (TextView) view.findViewById(R.id.icon_detail);
			TextView logdetails = (TextView) view.findViewById(R.id.log_detail);
			TextView callduration= (TextView) view.findViewById(R.id.calllog_duration);
			TextView contact = (TextView) view.findViewById(R.id.sipUri);
			
			contact.setSelected(true); // For automated horizontal scrolling of long texts
			
			ImageView callDirection = (ImageView) view.findViewById(R.id.icon);
			
			TextView separator = (TextView) view.findViewById(R.id.separator);
			Calendar logTime = Calendar.getInstance();
			logTime.setTimeInMillis(timestamp);
			separator.setText(timestampToHumanDate(logTime));
			
			if (position > 0) {
				LinphoneCallLog previousLog = childlog.get(position-1);
				long previousTimestamp = previousLog.getTimestamp();
				Calendar previousLogTime = Calendar.getInstance();
				previousLogTime.setTimeInMillis(previousTimestamp);

				if (isSameDay(previousLogTime, logTime)) {
					separator.setVisibility(View.GONE);
				} else {
					separator.setVisibility(View.VISIBLE);
				}
			} else {
				separator.setVisibility(View.VISIBLE);
			}
			
			if (log.getDirection() == CallDirection.Incoming) {
				address = log.getFrom();
				if (log.getStatus() == CallStatus.Missed) {
					callDirection.setImageBitmap(missedCall);
					icondetails.setText(R.string.call_state_missed);
				} else {
					callDirection.setImageBitmap(incomingCall);
					icondetails.setText(R.string.call_state_incoming);
				}
			} else {
				address = log.getTo();
				callDirection.setImageBitmap(outgoingCall);
				icondetails.setText(R.string.call_state_outgoing);
			}
			
			/*
			String callTime = secondsToDisplayableString(log.getCallDuration());
			
			String callDate = String.valueOf(log.getTimestamp());
			logdetails.setText(timestampToHumanDate1(callDate));
			*/
			String callDate = String.valueOf(log.getTimestamp());
			logdetails.setText(timestampToHumanDate1(callDate));
			
			String callTime = secondsToDisplayableString(log.getCallDuration());
			callduration.setText(callTime);
			
			LinphoneUtils.findUriPictureOfContactAndSetDisplayName(address, view.getContext().getContentResolver());
			String displayName = address.getDisplayName(); 
			String sipUri = address.asStringUriOnly();
			String str=Utilites.getNumberFromString(sipUri);
			if(!str.isEmpty()){
				contact.setText(Utilites.setNumberFormat(str.substring(1, str.length())));}
			else{
				contact.setText(displayName);	
				}
			/*
			if (displayName == null) {
				if (getResources().getBoolean(R.bool.only_display_username_if_unknown) && LinphoneUtils.isSipAddress(sipUri)) {
					contact.setText(LinphoneUtils.getUsernameFromAddress(sipUri));
				} else {
					contact.setText(sipUri);
				}
			} else {
				if (getResources().getBoolean(R.bool.only_display_username_if_unknown) && LinphoneUtils.isSipAddress(address.getDisplayName())) {
					contact.setText(LinphoneUtils.getUsernameFromAddress(address.getDisplayName()));
				} else {
					contact.setText(displayName);
				}
			}
			*/
			
			view.setTag(sipUri);
			
			return view;
		}		  
	  }
	
	
	private String secondsToDisplayableString(int secs) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		cal.set(0, 0, 0, 0, 0, secs);
		return dateFormat.format(cal.getTime());
	}
	
	@SuppressLint("SimpleDateFormat")
	private String timestampToHumanDate1(String timestamp) {
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(Long.parseLong(timestamp));
		
		SimpleDateFormat dateFormat;
		dateFormat = new SimpleDateFormat(getResources().getString(R.string.history_detail1_date_format));
		return dateFormat.format(cal.getTime());
	}
	
}
	
	
	
	

