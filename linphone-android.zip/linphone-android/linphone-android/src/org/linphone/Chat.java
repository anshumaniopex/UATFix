package org.linphone;

public class Chat {
  	 
    private int id;
    private int Type;
    private String DateTime;
    private String Number;
    private String Message;
 
    public Chat(){}
 
    public Chat(int Type,String DateTime, String Number,String Message) {
        super();
        this.Type = Type;
        this.DateTime = DateTime;
        this.Number = Number;
        this.Message = Message;
    }
 
    //getters & setters
 
    @Override
    public String toString() {
        return "Chat [id=" + id + ", Type=" + Type + ",DateTime=" + DateTime + ",Number=" + Number + ", Message=" + Message
                + "]";
    }
    public int getid()
    {
    	return id;
    }
    public int getType()
    {
    	return Type;
    }
   public String getTime()
   {
	   return DateTime;
   }

    public String getMessage()
    {
    	return Message;
    }
    public String getNumber()
    {
    	
    	return Number;
    }
    public void setId(int iD)
    {
    	this.id = iD;
    }
    public void setTime(String Time)
    {
    	this.DateTime = Time;
    }
    public void setType(int Type)
    {
    	this.Type = Type;
    }
    public void setNumber(String Number)
    {
    	this.Number = Number;
    }
    public void setMessage(String Message)
    {
    	this.Message = Message;
    }
    
}
