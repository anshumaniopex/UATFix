package org.linphone;

public class TNotifier {

	public void notify(String s) {
		System.out.println(s);
	}
}