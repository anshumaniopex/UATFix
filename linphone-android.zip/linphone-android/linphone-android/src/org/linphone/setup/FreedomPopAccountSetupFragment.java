package org.linphone.setup;

import java.io.BufferedReader;

import org.linphone.*;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import android.provider.*;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.StatusLine;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.linphone.GcmIntentService;
import org.linphone.LinphoneActivity;
import org.linphone.R;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.gcm.GoogleCloudMessaging;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v4.app.Fragment;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupWindow;

import java.io.*;

public class FreedomPopAccountSetupFragment extends Fragment implements OnClickListener{
	PopupWindow pwindo,pmessagewindo;
	Button btnSubmitPopup;
	EditText pMailId;
	String QueryResult;
	Context cxt;
	String username, password,server;
	String CLIENT_ID,SECRET,PROTOCOL,SERVICE_URL;
	public int responseCode=0;
	public String response;
	public static String FREE_POP_ACCE="";
	View view,parent;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.setup_freedompop_login, container, false);
		cxt=view.getContext();
		CLIENT_ID = cxt.getString(R.string.CLIENT_ID);
	    SECRET = cxt.getString(R.string.SECRET);
	    PROTOCOL = cxt.getString(R.string.PROTOCOL);
	    SERVICE_URL  = cxt.getString(R.string.SERVICE_URL);
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
	    StrictMode.setThreadPolicy(policy); IntentFilter intentFilter = new IntentFilter();
	    freedomlogin();
		return view;
	}

	private void initiateMessageWindow() {
		
		LayoutInflater inflater = (LayoutInflater) FreedomPopAccountSetupFragment.this
				.cxt.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View layout = inflater.inflate(R.layout.email_message, null);
		pmessagewindo = new PopupWindow(layout,575,LayoutParams.WRAP_CONTENT,true);
		pmessagewindo.showAtLocation(layout, Gravity.CENTER,0, 0); 
		Button btnOk = (Button) layout.findViewById(R.id.pok);
		btnOk.setOnClickListener(this);
	}
	
	
	
	private void initiateEmailWindow() { 
		LayoutInflater inflater = (LayoutInflater) FreedomPopAccountSetupFragment.this
				.cxt.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		final View layout = inflater.inflate(R.layout.email, null);
		pwindo = new PopupWindow(layout,LayoutParams.MATCH_PARENT,LayoutParams.WRAP_CONTENT,true);
		layout.post(new Runnable() {
	        public void run() {
	        	pwindo.showAtLocation(layout, Gravity.CENTER,0, 0);
	        }
	    });
		
		btnSubmitPopup = (Button) layout.findViewById(R.id.pSubmit);
		pMailId=(EditText)layout.findViewById(R.id.pemail);
		btnSubmitPopup.setOnClickListener(this);
		
		}
	
	private void freedomlogin(){
		Log.i(FreedomPopAccountSetupFragment.class.getName(),"========================== ");
		initiateEmailWindow();
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId()==R.id.pSubmit){
			Log.i(FreedomPopAccountSetupFragment.class.getName(),"========================== ");
			if(isNetworkAvailable()){
			try {
				if(isMailId(pMailId.getText().toString()))
				{
////					password = "42xsgseh7j9KFhi3";
////					username = "kamalgar";
//					server = "getonsip.com";
					TelephonyManager telephonyManager = (TelephonyManager)getActivity().getSystemService(getActivity().TELEPHONY_SERVICE);
					String deviceId = telephonyManager.getDeviceId();
		            StringBuilder Usr = new StringBuilder();
		            	                     
					SetupActivity.instance().genericLogIn(username, password,server);
					pwindo.dismiss();
				}else{
					pMailId.setText("");
				}
			} catch (ClientProtocolException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (URISyntaxException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}else{
				initiateMessageWindow();
			}
		}else if (v.getId()==R.id.pok){
			pmessagewindo.dismiss();
		}
	}
	
	
	private boolean executeGetMethod(String accessToken,String UserName){
		Log.i("","=======executeGetMethod======");
		String combinedParams = "";
		combinedParams += "?";
		String paramString1 = "";
		String paramString2 = "";
		try {
			
			TelephonyManager telephonyManager = (TelephonyManager)getActivity().getSystemService(getActivity().TELEPHONY_SERVICE);
			String deviceId = telephonyManager.getDeviceId();
			String url = "https://api.freedompop.com/api/phone/device/config/?";
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(3);
			nameValuePairs.add(new BasicNameValuePair("appVersion","FPOP_PHONE:12.0.0.0"));
			nameValuePairs.add(new BasicNameValuePair("deviceId", deviceId));
			nameValuePairs.add(new BasicNameValuePair("accessToken", accessToken));
			
			HttpClient httpClient = new DefaultHttpClient();
			String paramsString = URLEncodedUtils.format(nameValuePairs, "UTF-8");
			StringBuilder CompleteUri = new StringBuilder();
			CompleteUri.append(url);
			CompleteUri.append(paramsString);
			HttpGet httpGet = new HttpGet(CompleteUri.toString());
			HttpResponse response = httpClient.execute(httpGet);
		
			//paramString1 = "deviceId" + "=" + URLEncoder.encode(deviceId,"UTF-8");
			//combinedParams += paramString1;
			//combinedParams += "&";
			//paramString2 = "accessToken" + "=" + URLEncoder.encode(accessToken,"UTF-8");
			//combinedParams += paramString2;
			//URI uri = new URI(SERVICE_URL+"/api/phone/config/"+ combinedParams);
			//HttpGet request = new HttpGet(uri);
			//HttpClient client = new DefaultHttpClient();
	        //HttpResponse httpResponse;
	        //httpResponse = client.execute(request);
            responseCode = response.getStatusLine().getStatusCode();
            String message  = response.getStatusLine().getReasonPhrase();
            HttpEntity entity = response.getEntity();
            
            if(responseCode == 200)
            {
               	if (entity != null)
            	{
            		InputStream instream = entity.getContent();
            		
            		QueryResult = convertStreamToString(instream);
            		instream.close();
            		Intent openActivity = new Intent(getActivity(),LinphoneActivity.class);
            		openActivity.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            		startActivity(openActivity);
            	}
            }else if(responseCode == 400)
            {
            	//Missing Phone Number case
            	InputStream instream = entity.getContent();
        		QueryResult = convertStreamToString(instream);
        		instream.close();
            	//freedomlogin();
            }
            	Log.i("------------------",QueryResult);
            	return getAccountFreedomPopInfo();
            
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
		
			e.printStackTrace();
		}
//		} catch (URISyntaxException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}

		return false;
		
	}
	
	
	
	private boolean executePostMethod(String Username) throws URISyntaxException, ClientProtocolException, IOException{
		Log.i("","=======executePostMethod======");
		String deviceId = null;
		TelephonyManager telephonyManager = (TelephonyManager)getActivity().getSystemService(getActivity().TELEPHONY_SERVICE);
		deviceId = telephonyManager.getDeviceId();
   	   // deviceId = Settings.Secure.getString(getActivity().getContentResolver(),Settings.Secure.ANDROID_ID);
	   	if(deviceId != null)
	   	 {
	   			//deviceId = "367777778888812"; 
	   			URI uri;
	   		   	HttpPost request;
	   		   	UrlEncodedFormEntity entityReq;
	   		   	uri = new URI(SERVICE_URL+"/api/auth/token");
	   		   	request = new HttpPost(uri);
	   		   	ArrayList<NameValuePair> params;
	   		   	params = new ArrayList<NameValuePair>();
	   			Log.i("*********DeviceId***************",deviceId);  			
	   			params.add(new BasicNameValuePair("grant_type","device_meid"));
			   	params.add(new BasicNameValuePair("username",Username));
			   	params.add(new BasicNameValuePair("device_id", deviceId));
			    entityReq = new UrlEncodedFormEntity(params);
			    entityReq.setContentEncoding(HTTP.UTF_8);
			    entityReq.setContentType("application/x-www-form-urlencoded");
			    request.setEntity(entityReq);
			    request.addHeader(BasicScheme.authenticate
				(new UsernamePasswordCredentials(CLIENT_ID+":"+SECRET), "UTF-8", false));
			    HttpClient client = new DefaultHttpClient();
			    HttpEntity entityResp = null;
			    HttpResponse response;
			    response = client.execute(request);
			    String responseText;
			    entityResp = response.getEntity();
			    StatusLine statusLine = response.getStatusLine();
			   	int statusCode = statusLine.getStatusCode();
				String statusPhrase = statusLine.getReasonPhrase();
				Log.i("I","Type: "+entityResp.getContentType());
				Log.i("I","status: "+statusCode + " - "+statusPhrase);
				responseText = EntityUtils.toString(entityResp);
				entityResp.consumeContent();
				entityResp = null;
				if(statusCode==200){
				JSONObject jsonObj;
						try {
									jsonObj = new JSONObject(responseText);
									String accessToken = jsonObj.getString("access_token");
									FileOutputStream fos = getActivity().openFileOutput("FreedomPOP.dat",getActivity().MODE_PRIVATE);
									OutputStreamWriter osw = new OutputStreamWriter(fos);
									osw.write(accessToken);
									osw.flush();
									osw.close();
									FREE_POP_ACCE=accessToken;
									return executeGetMethod(accessToken,Username);
							} catch (JSONException e) {
									// TODO Auto-generated catch block
								e.printStackTrace();
							}
				   	    }
	   				}
	   			  		
		 	
	   			return false;
		
	}
	
	private boolean getAccessToken(String Username) throws ClientProtocolException, URISyntaxException, IOException{
			return executePostMethod(Username);
	}
	
	private boolean isMailId(String email) throws ClientProtocolException, URISyntaxException, IOException{
		if(!email.equals("")){
			SharedPreferences p = this.getActivity().getSharedPreferences(FreedomPopAccountSetupFragment.class.getSimpleName(), 0);
			if(p != null){
				Editor editor = p.edit();
				editor.putString("Email",email);
				editor.commit();
			}
		return readFreedomPopAccountInfo(email);
		}
		return false;
	}
	
	private boolean readFreedomPopAccountInfo(String Username) throws ClientProtocolException, URISyntaxException, IOException{
		return getAccessToken(Username);
	}
	
	/*
	
	*/
	private boolean getAccountFreedomPopInfo(){
	try {
		Log.i(FreedomPopAccountSetupFragment.class.getName(),"DATA Anshuman "+QueryResult);
			JSONObject jsonObj = new JSONObject(QueryResult);
			String id = jsonObj.getString("id");
			Log.i("****************id***************",id);
			String status = jsonObj.getString("status");
			String externalId = jsonObj.getString("externalId");
			Log.i("****************externalId***************",externalId);
			String accountName = jsonObj.getString("accountName");
			Log.i("****************accountName***************",accountName);
			 server = jsonObj.getString("server");
			 Log.i("****************server***************",server);
			 username = jsonObj.getString("username");
			 Log.i("****************username***************",username);
			 password = jsonObj.getString("password");
			 Log.i("****************password***************",password);
				
				FileOutputStream fos = getActivity().openFileOutput("fppassword.dat",getActivity().MODE_PRIVATE);
				OutputStreamWriter osw = new OutputStreamWriter(fos);
				osw.write(password);
				osw.flush();
				osw.close();
			 
			 SharedPreferences p = getActivity().getSharedPreferences(FreedomPopAccountSetupFragment.class.getSimpleName(), 0);
				if(p != null){
					Editor editor = p.edit();
					editor.commit();
					editor.putString("UserName",username);
					editor.commit();
				}
		   } catch (Exception e) {
		      e.printStackTrace();
		      return false;
		    }
		return true;
	}
	
	private boolean isNetworkAvailable() {
	    ConnectivityManager connectivityManager 
	          = (ConnectivityManager) FreedomPopAccountSetupFragment.this
	  				.cxt.getSystemService(Context.CONNECTIVITY_SERVICE);
	    NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
	    return activeNetworkInfo != null && activeNetworkInfo.isConnected();
	}


	private class LongOperation extends AsyncTask<String, Void, String> {

		@Override
		protected String doInBackground(String... arg0) {
			// TODO Auto-generated method stub
			//QueryResult=readFreedomPopAccountInfo();
			Log.i(FreedomPopAccountSetupFragment.class.getName(),"readFreedomPopAccountInfo: "+QueryResult);
			return null;
		}
		
		
		
	}
	private static String convertStreamToString(InputStream is)
	{
	    BufferedReader reader = new BufferedReader(new InputStreamReader(is));
	    StringBuilder sb = new StringBuilder();
	    String line = null;
	    try
	    {
	        while ((line = reader.readLine()) != null)
	        {
	            sb.append(line + "\n");
	        }
	        is.close();
	    }
	    catch (IOException e)
	    { }
	    return sb.toString();
	}
}
