package org.linphone;

import java.util.LinkedList;
import java.util.List;

import android.app.Application;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class FPDatabase extends Application {
	public MySQLite iMySqlite;
	public void SetDatabase()
	{
		iMySqlite = new MySQLite(this);
	}
	public MySQLite getDatabse()
	{
		return iMySqlite;
	}
}
