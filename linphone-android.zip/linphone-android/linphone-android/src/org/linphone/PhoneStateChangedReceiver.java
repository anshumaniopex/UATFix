package org.linphone;

import org.linphone.mediastream.Log;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;

/**
 * Pause current SIP calls when GSM phone rings or is active.
 * 
 * @author Guillaume Beraudo
 *
 */
public class PhoneStateChangedReceiver extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {


		final String extraState = intent.getStringExtra(TelephonyManager.EXTRA_STATE);

		if (TelephonyManager.EXTRA_STATE_RINGING.equals(extraState) || TelephonyManager.EXTRA_STATE_OFFHOOK.equals(extraState)) {
			LinphoneManager.setGsmIdle(false);
			if (!LinphoneManager.isInstanciated()) {
				Log.i("GSM call state changed but manager not instantiated");
				return;
			}
			LinphoneManager.getLc().pauseAllCalls();
        } else if (TelephonyManager.EXTRA_STATE_IDLE.equals(extraState)) {
        	LinphoneManager.setGsmIdle(true);
        }
		
		 
		// do nothing
	}

}
