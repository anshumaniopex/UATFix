/** Automatically generated file. DO NOT MODIFY */
package org.linphone.tester;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}