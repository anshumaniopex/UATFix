package org.linphone;

public class PeopleContact {
	String name;
	String number;
	
	String getName(){
		return name;
	}
	
	String getNumber(){
		return number;
	}
	
	
	void setName(String str){
		this.name=str;
	}
	
	void setNumber(String str){
		this.number=str;
	}
	
	
}
