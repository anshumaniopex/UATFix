package org.linphone;

import java.util.ArrayList;
import java.util.List;

import org.linphone.compatibility.Compatibility;
import org.linphone.core.LinphoneFriend;
import org.linphone.core.LinphoneProxyConfig;
import org.linphone.core.OnlineStatus;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.provider.ContactsContract;
import android.provider.Contacts.People;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SimpleCursorAdapter;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AlphabetIndexer;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SectionIndexer;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class ChatFragmentNew extends Fragment implements OnClickListener, OnItemClickListener {
	private LayoutInflater mInflater;
	private ListView contactList;
	private Context cxt;
	private ArrayList<PeopleContact> contactArray;
	private ArrayList<PeopleContact> contactsearchArray;
	ContactChatListAdapter contactChatListAdapter;
	SuggestionsFilter filter; 
	TextView fok,fcancel;
	EditText chatContactInput; 
	private Handler mHandler = new Handler();
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		mInflater = inflater;
		View view = inflater.inflate(R.layout.fnew_chat, container, false);	
		cxt=view.getContext();
		contactList=(ListView)view.findViewById(R.id.fchatList);
		contactList.setOnItemClickListener(this);
		registerForContextMenu(contactList);
		
		
		fok=(TextView)view.findViewById(R.id.fok);
		fok.setOnClickListener(this);
		
		fcancel=(TextView)view.findViewById(R.id.fcancel);
		fcancel.setOnClickListener(this);
		
		chatContactInput=(EditText)view.findViewById(R.id.fuser);
		chatContactInput.setOnClickListener(this);
		chatContactInput.addTextChangedListener(new TextWatcher(){

			@Override
			public void afterTextChanged(Editable arg0) {
				// TODO Auto-generated method stub
				contactChatListAdapter.setSearch(chatContactInput.getText().toString());
			}

			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1,
					int arg2, int arg3) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2,
					int arg3) {
				// TODO Auto-generated method stub
				
			}
			
		});
		
		contactArray= new ArrayList<PeopleContact>();
		contactsearchArray = new ArrayList<PeopleContact>();
		
	return view;	
	}
	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		int id = arg0.getId();
		if(id == R.id.fok){
			String sipUri = chatContactInput.getText().toString();
			if (sipUri.equals("")) {
				LinphoneActivity.instance().changeCurrentFragmentans(FragmentsAvailable.CHATLIST, null);	
			}else{
				if(contactsearchArray.size()>0){
					 PeopleContact entry = contactsearchArray.get(0);  	
					 if(entry.getName().toLowerCase().equals(sipUri.toLowerCase())){
								if (LinphoneActivity.isInstanciated()){
								LinphoneActivity.instance().displayChat(getNumberInLinphoneFormat
										(Utilites.getNumString(entry.getNumber())));
						     } 
					 }
					 else{
						   if(!LinphoneUtils.isSipAddress(sipUri)) {
								if (LinphoneManager.getLc().getDefaultProxyConfig() == null) {
									return;
								}
								sipUri = sipUri + "@" + LinphoneManager.getLc().getDefaultProxyConfig().getDomain();
							}
							if (!LinphoneUtils.isStrictSipAddress(sipUri)) {
								sipUri = "sip:" + sipUri;
							}
							LinphoneActivity.instance().displayChat(sipUri); 	 
					 }
				}else{
				
					   if(!LinphoneUtils.isSipAddress(sipUri)) {
						if (LinphoneManager.getLc().getDefaultProxyConfig() == null) {
							return;
						}
						sipUri = sipUri + "@" + LinphoneManager.getLc().getDefaultProxyConfig().getDomain();
					}
					if (!LinphoneUtils.isStrictSipAddress(sipUri)) {
						sipUri = "sip:" + sipUri;
					}
					LinphoneActivity.instance().displayChat(sipUri);	
					
				}
			}
		}else if(id == R.id.fcancel){
			if (LinphoneActivity.isInstanciated()){
			LinphoneActivity.instance().changeCurrentFragmentans(FragmentsAvailable.CHATLIST, null);
		}
		}
	}

	
  @Override
	public void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		if (LinphoneActivity.isInstanciated()){
			LinphoneActivity.instance().setmessage("New Message");
			}
	
		invalidate();
	}
  
  public void invalidate() {
		mHandler.post(new Runnable() {
			@Override
			public void run() {
				if (LinphoneActivity.isInstanciated()){
					contactArray=LinphoneActivity.instance().getAllforChatContacts();
					contactsearchArray=contactArray;
					}
					contactChatListAdapter =new ContactChatListAdapter(contactsearchArray);
					contactList.setAdapter(contactChatListAdapter );
			}
		});
	}
	
  
  
  
  class ContactChatListAdapter extends BaseAdapter implements Filterable{
	  
	  ArrayList<PeopleContact> contactList;
	  ContactChatListAdapter(ArrayList<PeopleContact> contactList){
		  this.contactList=contactList;
	  }

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		if(filter!=null){
			return contactsearchArray.size();
		}else{
			return contactList.size();	
		}
		
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		View view = null;
		
		if (convertView != null) {
			view = convertView;
		} else {
			view = mInflater.inflate(R.layout.fnew_chat_list_cell, parent, false);
			
		}
		PeopleContact entry = contactsearchArray.get(position);
		TextView name = (TextView) view.findViewById(R.id.name);
		name.setText(entry.getName());
		
		TextView number = (TextView) view.findViewById(R.id.number);
		number.setText(setNumberFormat(entry.getNumber()));
		view.setTag(entry);
		
		return view;
	}

	//
	public void setSearch(String serChar){
		Log.d("setSearch","setSearch"+serChar);
		if (contactArray.size()> 1){		
			if (serChar.equals("-1")){
				Log.d("setSearch","setSearch -1");
				this.getFilter().filter("");
			}else {
				Log.d("setSearch","setSearch ok");
				this.getFilter().filter(serChar);

			}
		}
	}
  
	@Override
	public Filter getFilter() {
		// TODO Auto-generated method stub
		 if (filter == null){
		      filter  = new SuggestionsFilter();
		    }
		return filter;
	}
	  
  }

  private class SuggestionsFilter extends Filter {

	@Override
	protected FilterResults performFiltering(CharSequence constraint) {
		// TODO Auto-generated method stub
		FilterResults results = new FilterResults();
		ArrayList<PeopleContact> contactselected =new ArrayList<PeopleContact>(); ;
		if (constraint!= null && constraint.toString().length() > 0) {
			for (int index = 0; index < contactArray.size(); index++) {
			 PeopleContact entry = contactArray.get(index);
			 if(entry.getName().toLowerCase().startsWith(constraint.toString().toLowerCase()) || 
					 entry.getNumber().startsWith(constraint.toString())){
				 contactselected.add(entry);
			 }
			}
			results.values = contactselected;
            results.count = contactselected.size();  
            Log.d("Filter","performFiltering I>>> size:"+contactselected.size());
		}else {
			 synchronized (contactArray){
                 results.values = contactArray;
                 results.count = contactArray.size();
             }
	}
		return results;
	}

	@Override
	protected void publishResults(CharSequence constraint,FilterResults results) {
		// TODO Auto-generated method stub
		Log.d("Filter","publishResults");
		contactsearchArray=(ArrayList<PeopleContact>)results.values;
		Log.d("Filter Size",":"+contactsearchArray.size());
		contactChatListAdapter.notifyDataSetChanged();
	}
	  
  }

@Override
public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
	// TODO Auto-generated method stub
	
	PeopleContact entry = (PeopleContact) arg1.getTag();
	
	Log.d("onItemClicked","clicked "+entry.getName());
	Log.d("onItemClicked","clicked "+entry.getNumber());
	if (LinphoneActivity.isInstanciated()){
		LinphoneActivity.instance().displayChat(getNumberInLinphoneFormat
				(Utilites.getNumString(entry.getNumber())));
     }

}
 
public String getNumberInLinphoneFormat(String Number){
	
	LinphoneProxyConfig lpc = LinphoneManager.getLc().getDefaultProxyConfig();
	String tag = Number;
	
	if (lpc != null) {
		if (!Number.startsWith("sip:")) {
			Number  = "sip:" + Number ;
		}
		
		if (!Number.contains("@")) {
			tag = Number+ "@" + lpc.getDomain();
		}
	} 
	 return tag;
}

public static String setNumberFormat(String Number){
	
	try {
		return Number.replaceAll("(\\d{3})(\\d{3})(\\d{4})", "($1) $2-$3");
	} catch (Exception e) {
		// TODO Auto-generated catch block
		
		e.printStackTrace();
	}
	return Number;
}
 
}
