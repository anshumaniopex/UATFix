package org.linphone;

import static android.content.Intent.ACTION_MAIN;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.List;

import org.linphone.HistoryFragment.CallHistoryAdapter;
import org.linphone.LinphoneManager.AddressType;
import org.linphone.LinphoneSimpleListener.LinphoneOnCallStateChangedListener;
import org.linphone.LinphoneSimpleListener.LinphoneOnMessageReceivedListener;
import org.linphone.LinphoneSimpleListener.LinphoneOnRegistrationStateChangedListener;
import org.linphone.compatibility.Compatibility;
import org.linphone.core.CallDirection;
import org.linphone.core.LinphoneAddress;
import org.linphone.core.LinphoneCall;
import org.linphone.core.LinphoneCall.State;
import org.linphone.core.LinphoneCallLog;
import org.linphone.core.LinphoneCallLog.CallStatus;
import org.linphone.core.LinphoneChatMessage;
import org.linphone.core.LinphoneChatRoom;
import org.linphone.core.LinphoneCore;
import org.linphone.core.LinphoneCore.RegistrationState;
import org.linphone.core.LinphoneCoreException;
import org.linphone.core.LinphoneCoreFactory;
import org.linphone.core.LinphoneFriend;
import org.linphone.core.OnlineStatus;
import org.linphone.mediastream.Log;
import org.linphone.setup.FreedomPopAccountSetupFragment;
import org.linphone.setup.SetupActivity;
import org.linphone.ui.AddressText;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.Fragment.SavedState;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.OrientationEventListener;
import android.view.Surface;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
/*Start for Push Notification Integration */
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.AsyncTask;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.view.View;
import android.widget.*;
//import org.linphone.util.Log;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.gcm.GoogleCloudMessaging;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.StatusLine;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.*;


public class LinphoneActivity extends FragmentActivity implements
		OnClickListener, ContactPicked, LinphoneOnCallStateChangedListener,
		LinphoneOnMessageReceivedListener,
		LinphoneOnRegistrationStateChangedListener {

	public static final String PREF_FIRST_LAUNCH = "pref_first_launch";
	private static final int SETTINGS_ACTIVITY = 123;
	private static final int FIRST_LOGIN_ACTIVITY = 101;
	private static final int callActivity = 19;
	String CLIENT_ID,SECRET,PROTOCOL,SERVICE_URL;
	private Class<? extends Activity> incomingReceivedActivity = LinphoneActivity.class;

	String QueryResult;
	Context cxt;
	String username, password,server,deviceId;
	public int responseCode=0;
	public String response;
	public static String FREE_POP_ACCE="";
	private static LinphoneActivity instance;
	private final String SENDER_ID = "217426578503";
	public static final String PROPERTY_PUSH_TOKEN = "registration_id";
	private static final String PROPERTY_APP_VERSION = "appVersion";
	private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
	private LayoutInflater mInflater;
	GoogleCloudMessaging gcm;
	Context context;
	String pushToken;
	View view,parent;
	private StatusFragment statusFragment;
	private TextView missedCalls, missedChats,mDisplay;
	private RelativeLayout dialer;
	private LinearLayout menu,menu1, mark;
	private RelativeLayout contacts, history, settings, chat;
	private FragmentsAvailable currentFragment, nextFragment;
	private List<FragmentsAvailable> fragmentsHistory;
	private Fragment dialerFragment, messageListenerFragment, messageListFragment, friendStatusListenerFragment;
	private SavedState dialerSavedState;
	private boolean preferLinphoneContacts = false, isAnimationDisabled = false, isContactPresenceDisabled = true;
	private Handler mHandler = new Handler();
	private List<Contact> contactList, sipContactList;
	private Cursor contactCursor, sipContactCursor;
	private OrientationEventListener mOrientationHelper;
	private ArrayList<PeopleContact> contactArray;
	Notification pushNoti;
	private PendingIntent mNotifContentIntent;
	private PendingIntent mkeepAlivePendingIntent;
	private String mNotificationTitle;
	NotificationManager notificationManager;
	int PUSH_ID=9999;
	static final boolean isInstanciated() {
		return instance != null;
	}

	public static final LinphoneActivity instance() {
		if (instance != null)
			return instance;
		throw new RuntimeException("LinphoneActivity not instantiated yet");
	}

	@SuppressWarnings("deprecation")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

	
		if (!LinphoneService.isReady())  {
			startService(new Intent(ACTION_MAIN).setClass(this, LinphoneService.class));
		}

		// Remove to avoid duplication of the listeners
		if (isTablet() && getRequestedOrientation() != ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE) {
      		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        } else if (!isTablet() && getRequestedOrientation() != ActivityInfo.SCREEN_ORIENTATION_PORTRAIT) {
        	setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
		
		if (!LinphoneManager.isInstanciated()) {
			Log.e("No service running: avoid crash by starting the launcher", this.getClass().getName());
			finish();
			startActivity(getIntent().setClass(this, LinphoneLauncherActivity.class));
			return;
		}

		boolean useFirstLoginActivity = getResources().getBoolean(R.bool.display_account_wizard_at_first_start);
		if (useFirstLoginActivity && LinphonePreferences.instance().isFirstLaunch()) {
			if (LinphonePreferences.instance().getAccountCount() > 0) {
				LinphonePreferences.instance().firstLaunchSuccessful();
			} else {
				startActivityForResult(new Intent().setClass(this, SetupActivity.class), FIRST_LOGIN_ACTIVITY);
			}
		}
	
		setContentView(R.layout.main);
		instance = this;
		fragmentsHistory = new ArrayList<FragmentsAvailable>();
		initButtons();
		CLIENT_ID = "1657042864";
	    SECRET    = "iabx4FoK3ogd2s9Mhhori7pSC9VrQyBA";
	    SERVICE_URL = "https://api.freedompop.com";
		currentFragment = nextFragment = FragmentsAvailable.DIALER;
		fragmentsHistory.add(currentFragment);
		if (savedInstanceState == null) {
			if (findViewById(R.id.fragmentContainer) != null) {
			
				dialerFragment = new DialerFragment();
				dialerFragment.setArguments(getIntent().getExtras());
				getSupportFragmentManager().beginTransaction().add(R.id.fragmentContainer, dialerFragment, currentFragment.toString()).commit();
				selectMenu(FragmentsAvailable.DIALER);
			}
		}

		int missedCalls = LinphoneManager.getLc().getMissedCallsCount();
		displayMissedCalls(missedCalls);

		int rotation = getWindowManager().getDefaultDisplay().getRotation();
		switch (rotation) {
		case Surface.ROTATION_0:
			rotation = 0;
			break;
		case Surface.ROTATION_90:
			rotation = 90;
			break;
		case Surface.ROTATION_180:
			rotation = 180;
			break;
		case Surface.ROTATION_270:
			rotation = 270;
			break;
		}

		LinphoneManager.getLc().setDeviceRotation(rotation);
		mAlwaysChangingPhoneAngle = rotation;

		updateAnimationsState();
		notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
		IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction(GcmIntentService.RECEIVED_PUSH_NOTIFICATION);
		registerReceiver(pushNotificationReceiver, 
	   			intentFilter);
	 
	}

	/**triggerPush() : API is used to initiate the push 
	 * registration with FreedomPop Server
	 */
	
	public void triggerPush(){
		
	 	Log.i("In onCreate...");
		context = getApplicationContext();
		String email =null;
		if(checkPlayServices())
		{
				SharedPreferences p = getSharedPreferences(FreedomPopAccountSetupFragment.class.getSimpleName(), 0);
				if(p != null){
				email = p.getString("Email","");
				}
				if(email.isEmpty())
				{
					Log.i("Email is Empty wait user to enter");
				}else
				{
					Log.i("Inside checkPlayServices....");
					gcm = GoogleCloudMessaging.getInstance(this);
					pushToken = getLocallyStoredPushToken(context);
					String emailOrToken = null;
					emailOrToken=email;
					registerForPushWithGoogleAndFreedomPop(SERVICE_URL,emailOrToken);
				}
		}
		else
		{
			Log.i("No valid Google Play Services APK found.");
		}
			
}

	/**
	 * Check the device to make sure it has the Google Play Services APK. If
	 * it doesn't, display a dialog that allows users to download the APK from
	 * the Google Play Store or enable it in the device's system settings.
	 */
private boolean checkPlayServices(){

		int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
		if(resultCode != ConnectionResult.SUCCESS){
			if(GooglePlayServicesUtil.isUserRecoverableError(resultCode)){
			}
			else{
				Log.i("This device is not supported.");
			}
			return false;
		}
		return true;
}
	/**
	 * Stores the registration ID and the app versionCode in the application's
	 * {@code SharedPreferences}.
	 *
	 * @param context application's context.
	 * @param regId   registration ID
	 */
private void storePushTokenLocally(Context context, String regId){

		final SharedPreferences prefs = getGcmPreferences(context);
		int appVersion = getAppVersion(context);
		Log.i("Saving regId on app version " + appVersion);
		SharedPreferences.Editor editor = prefs.edit();
		editor.putString(PROPERTY_PUSH_TOKEN, regId);
		editor.putInt(PROPERTY_APP_VERSION, appVersion);
		editor.commit();
}
	
	/**
	 * Gets the current Push Token for application on GCM service, if there is one.
	 * <p/>
	 * If result is empty, the app needs to register.
	 *
	 * @return Push Token, or empty string if there is no existing
	 * registration ID.
	 */
private String getLocallyStoredPushToken(Context context){

		final SharedPreferences prefs = getGcmPreferences(context);
		String pushToken = prefs.getString(PROPERTY_PUSH_TOKEN, "");
		if(pushToken.length() == 0){
			Log.i("Registration not found.");
			return "";
		}
		// Check if app was updated; if so, it must clear the registration ID
		// since the existing regID is not guaranteed to work with the new
		// app version.
		int registeredVersion = prefs.getInt(PROPERTY_APP_VERSION, Integer.MIN_VALUE);
		int currentVersion = getAppVersion(context);
		if(registeredVersion != currentVersion){
			Log.i("App version changed.");
			return "";
		}
		return pushToken;
	}
	/**
	 * Registers the application with GCM servers asynchronously.
	 * <p/>
	 * Stores the registration ID and the app versionCode in the application's
	 * shared preferences.
	 */
private void registerForPushWithGoogleAndFreedomPop(String server, String emailOrToken){

		Log.i("Register in background...");

		new AsyncTask<String, Void, String>(){

			@Override
			protected String doInBackground(String... args){

				String msg;
				try{
					Log.i("Calling GCM");
					if(gcm == null){
						gcm = GoogleCloudMessaging.getInstance(context);
					}
					pushToken = gcm.register(SENDER_ID);

					msg = "Device registered with Google.\nPushToken = " + pushToken.substring(0,5)+"..."+pushToken.substring(pushToken.length()-6,pushToken.length()-1);
					Log.i(msg+"("+pushToken+")");

					// Call FreedomPop server to send registration info.
					Log.i("Sending push token to backend...");
					String server = args[0];       
					String emailOrToken = args[1];
					registerPushTokenWithFreedomPop(server,emailOrToken);
				    // Persist the regID - no need to register again.
					storePushTokenLocally(context, pushToken);
				}
				catch(IOException ex){
					Log.i( "Error :" + ex.getMessage());
					msg = ex.getMessage();
					
	
				}
				return msg;
			}

			@Override
			protected void onPostExecute(String msg){
             
				if(msg.contentEquals("SERVICE_NOT_AVAILABLE"))
                {
                	Log.i("Post Execute..."+pushToken +msg);
                	Log.i("Invoke again registerForPushWithGoogleAndFreedomPop");
                   	String email = null;
                 	SharedPreferences p = getSharedPreferences(FreedomPopAccountSetupFragment.class.getSimpleName(), 0);
    				if(p != null){
    		 	 	email = p.getString("Email","");
    				}
                	registerForPushWithGoogleAndFreedomPop(SERVICE_URL,email);
                }else
                {
                	Log.i("Post Execute..."+pushToken +msg);
                	
                }
			   
			}
		}.execute(server, emailOrToken);
	}

	/**
	 * @return Application's version code from the {@code PackageManager}.
	 */
	private static int getAppVersion(Context context){

		try{
			PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
			return packageInfo.versionCode;
		}
		catch(NameNotFoundException e){
			// should never happen
			throw new RuntimeException("Could not get package name: " + e);
		}
	}

	/**
	 * @return Application's {@code SharedPreferences}.
	 */
	private SharedPreferences getGcmPreferences(Context context){
		return getSharedPreferences(LinphoneActivity.class.getSimpleName(), Context.MODE_PRIVATE);
	}

	/**
	 * Register the push token with FreedomPop's server.
	 */
	private void registerPushTokenWithFreedomPop(String server, String emailOrToken){

		Log.i("Launching background task...");

		new AsyncTask<String, Void, String>(){

			@Override
			protected String doInBackground(String... args){

				Log.i("Setting up client in the background...");

				String server = args[0];
				String emailOrToken = args[1];
				if(server == null || emailOrToken == null){
					Log.e("Required arg is missing");
					return null;
				}

				HttpClient httpclient = new DefaultHttpClient();

				URI uri = null;
				URL url;
				try{
					String deviceId = null;
					deviceId = Settings.Secure.getString(getContentResolver(),Settings.Secure.ANDROID_ID);
					if(deviceId==null){

						Log.i("Device id could not be read, setting to all zeros.");
						deviceId = "0000000000000000";
					}

					String urlStr = "";

					String[] urlParts = server.split(":\\/\\/");

					String protocol = urlParts[0];
					String accessToken = "";
				
					Log.i("protocol: "+protocol);
					String serviceURL = urlParts[1];
					char[] buffer = new char[1024];
					Log.i("serviceURL: "+serviceURL);
					File file = getFileStreamPath("FreedomPOP.dat");
					if(file.exists())
					{
				    	FileInputStream fos = openFileInput("FreedomPOP.dat");
					    InputStreamReader isr = new InputStreamReader(fos);
					    isr.read(buffer);
					    accessToken = new String(buffer);
					}
				 	if(emailOrToken.contains("@")){
						Log.i("email: "+emailOrToken);
						Log.i("encoded email: "+URLEncoder.encode(emailOrToken));
		
						urlStr = protocol+"://"+serviceURL+"/api/phone/push/register/token?deviceType=FPOP_PHONE&deviceId="+deviceId+"&pushToken="+pushToken+"&accessToken="+accessToken;
					}
					else{
						
						urlStr = protocol+"://"+serviceURL+"/api/phone/push/register/token?deviceType=FPOP_PHONE&deviceId="+deviceId+"&pushToken="+pushToken+"&accessToken="+accessToken;
					}

					url = new URL(urlStr);
					uri = new URI(url.getProtocol(), url.getUserInfo(), url.getHost(), url.getPort(), url.getPath(), url.getQuery(), null);
					Log.i("Hitting URI at: "+uri);

				}
				catch(URISyntaxException e){
					Log.e("URISyntaxException: " + e.getMessage());
					e.printStackTrace();
					return null;
				}
				catch(MalformedURLException e){
					Log.e("MalformedURLException: " + e.getMessage());
					e.printStackTrace();
					return null;
				}  catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				HttpRequestBase request = new HttpGet(uri);
				Log.i("URI: " + request.getURI());

				HttpEntity entity = null;
				String responseText;
				StatusLine statusLine;
				int statusCode;
				try{

					HttpResponse response = httpclient.execute(request);

					entity = response.getEntity();
					statusLine = response.getStatusLine();
					statusCode = statusLine.getStatusCode();

					Log.i("Type: " + entity.getContentType());
					Log.i("statusCode: " + statusCode);
					responseText = EntityUtils.toString(entity);
					Log.i("ResponseText:\n" + responseText);

					if(statusCode == 200){

						Log.i("Server returned status OK.");
					}
					return responseText;
				}
				catch(ClientProtocolException e){
					Log.e("ClientProtocolException: " + e.getMessage());
				}
				catch(IOException e){

					Log.e("IOException -> " + e.getMessage());
				}
				finally{

					if(entity != null){
						try{
							entity.consumeContent();
						}
						catch(Exception e){
							Log.e("Exception in finally consuming entity: ", e);
						}
					}
				}
				return null;
			}

			@Override
			public void onPostExecute(String response){

				try{
					JSONTokener tokener = new JSONTokener(response);
					JSONObject responseJSON = new JSONObject(tokener);
					if(responseJSON != null){
						Boolean isSuccess = responseJSON.getBoolean("isSuccess");
						if(isSuccess != null && isSuccess){
							Log.i("Token successfully registered with FreedomPop\n");
							response = "Token successfully registered with FreedomPop\n";
						}
						else{
							String error = responseJSON.getString("error");
							String email = null;
							SharedPreferences p = getSharedPreferences(FreedomPopAccountSetupFragment.class.getSimpleName(), 0);
							if(p != null){
							email = p.getString("Email","");
							}
							if(email.isEmpty())
							{
								registerPushTokenWithFreedomPop(SERVICE_URL,email);
							}
							String error_desc = responseJSON.getString("error_description");
							response = "Error ->"+error+": "+error_desc;
					
						}
					}
				}
				catch(JSONException e){
					Log.i("JSONException",e.getMessage());
				}
				catch(NullPointerException e){
					Log.i("NullPointerException",e.getMessage());
					response = "FreedomPop server error when registering token: ";
				}
		}

		}.execute(server, emailOrToken);
		
	}

	public void unregisterReceiver(BroadcastReceiver receiver){
		super.unregisterReceiver(receiver);
	}
	
	@Override
	public Intent registerReceiver(BroadcastReceiver receiver, IntentFilter filter){
		return super.registerReceiver(receiver, filter);
	}

	public BroadcastReceiver pushNotificationReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {

			Log.i("Received a Broadcast!");

			Bundle extras = intent.getExtras();
			String body = extras.getString("body");
			String caller_id = extras.getString("caller_id");
			String collapse_key = extras.getString("collapse_key");
			String timeStamp = extras.getString("time_stamp");
			String msg_type = extras.getString("msg_type");

			Log.i("body -> "+body);
			Log.i("caller_id -> "+caller_id);
			Log.i("collapse_key -> "+collapse_key);
			Log.i("time_stamp -> "+timeStamp);
			Log.i("msg_type -> "+msg_type);

			if("SMS".equals(msg_type)){
				displayPushMessageNotification(caller_id,body,timeStamp);
			}
			
			if("PHONE_CALL".equals(msg_type)){
			    //Register with Push Provider and SIP Provider Push Incoming call notification
				displayPushMessageNotification(caller_id,body,timeStamp);
				String UserName = null;
				SharedPreferences p = getSharedPreferences(FreedomPopAccountSetupFragment.class.getSimpleName(), 0);
				if(p != null){
				UserName = p.getString("Email","");
				}
				File file = getFileStreamPath("FreedomPOP.dat");
				String accessToken = null;
				
				if(file.exists())
				{   
					try {
						char[] buffer = new char[1024];
				    	FileInputStream fos;
						fos = openFileInput("FreedomPOP.dat");
						InputStreamReader isr = new InputStreamReader(fos);
						accessToken = new String(buffer);
						//executeGetMethod(accessToken, UserName);
					    try {
							isr.read(buffer);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					   
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				    
				}
				//triggerPush();
				
			}
	
		}
	};
	private boolean executeGetMethod(String accessToken,String UserName){
		Log.i("","=======executeGetMethod======");
		String combinedParams = "";
		combinedParams += "?";
		String paramString;
		try {
			paramString = "accessToken" + "=" + URLEncoder.encode(accessToken,"UTF-8");
			combinedParams += paramString;
			URI uri = new URI(SERVICE_URL+"/api/phone/config/"+ combinedParams);
			HttpGet request = new HttpGet(uri);
			HttpClient client = new DefaultHttpClient();
	        HttpResponse httpResponse;
	        httpResponse = client.execute(request);
            responseCode = httpResponse.getStatusLine().getStatusCode();
            String message  = httpResponse.getStatusLine().getReasonPhrase();
            HttpEntity entity = httpResponse.getEntity();
            if (entity != null)
            {
                InputStream instream = entity.getContent();
                QueryResult = convertStreamToString(instream);
                instream.close();
                triggerPush();
                 
            }
            return getAccountFreedomPopInfo();
            
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return false;
		
	}
	
/*
	
	*/
	private boolean getAccountFreedomPopInfo(){
	try {
		Log.i(FreedomPopAccountSetupFragment.class.getName(),"DATA Anshuman "+QueryResult);
			JSONObject jsonObj = new JSONObject(QueryResult);
			String id = jsonObj.getString("id");
			String status = jsonObj.getString("status");
			String externalId = jsonObj.getString("externalId");
			String accountName = jsonObj.getString("accountName");
			 server = jsonObj.getString("server");
			 username = jsonObj.getString("username");
			 password = jsonObj.getString("password");
		   } catch (Exception e) {
		      e.printStackTrace();
		      return false;
		    }
		return true;
	}
	private static String convertStreamToString(InputStream is)
	{
	    BufferedReader reader = new BufferedReader(new InputStreamReader(is));
	    StringBuilder sb = new StringBuilder();
	    String line = null;
	    try
	    {
	        while ((line = reader.readLine()) != null)
	        {
	            sb.append(line + "\n");
	        }
	        is.close();
	    }
	    catch (IOException e)
	    { }
	    return sb.toString();
	}
	private boolean executePostMethod(String Username){

		try {

			URI uri;
			HttpPost request;
			UrlEncodedFormEntity entityReq;
			uri = new URI(SERVICE_URL+"/api/auth/token");
			request = new HttpPost(uri);
			ArrayList<NameValuePair> params;
			params = new ArrayList<NameValuePair>();
			String deviceId = null;
	   	    deviceId = Settings.Secure.getString(getContentResolver(),Settings.Secure.ANDROID_ID);
			params.add(new BasicNameValuePair("grant_type","device_meid"));
			params.add(new BasicNameValuePair("username",Username));
			params.add(new BasicNameValuePair("device_id", deviceId));
		    try {
				entityReq = new UrlEncodedFormEntity(params);
				entityReq.setContentEncoding(HTTP.UTF_8);
				entityReq.setContentType("application/x-www-form-urlencoded");
				request.setEntity(entityReq);
				request.addHeader(BasicScheme.authenticate
						(new UsernamePasswordCredentials(CLIENT_ID+":"+SECRET), "UTF-8", false));
				HttpClient client = new DefaultHttpClient();
			    HttpEntity entityResp = null;
			    HttpResponse response;
				try {
					response = client.execute(request);
					String responseText;
		            entityResp = response.getEntity();
		            StatusLine statusLine = response.getStatusLine();
		            int statusCode = statusLine.getStatusCode();
		            String statusPhrase = statusLine.getReasonPhrase();
					Log.i("I","Type: "+entityResp.getContentType());
					Log.i("I","status: "+statusCode + " - "+statusPhrase);
					responseText = EntityUtils.toString(entityResp);
					entityResp.consumeContent();
					entityResp = null;
					if(statusCode==200){
						JSONObject jsonObj;
						try {
							jsonObj = new JSONObject(responseText);
							String accessToken = jsonObj.getString("access_token");
							Log.i("","================"+accessToken);
							FREE_POP_ACCE=accessToken;
							return executeGetMethod(accessToken,Username);
							
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
		return false;
	}    
	public void displayPushMessageNotification(String caller_id,String Message,String time_stamp)
	{
		Intent notificationIntent = new Intent(this,incomingReceivedActivity);
		notificationIntent.putExtra("PushNotification", true);
		notificationIntent.putExtra("caller_id", caller_id);
		notificationIntent.putExtra("Message",Message);
		notificationIntent.putExtra("timeStamp",time_stamp);
	
		PendingIntent pendingIntent = PendingIntent.getActivity(this, 0,notificationIntent,PendingIntent.FLAG_UPDATE_CURRENT);
		pushNoti = new Notification.Builder(this)
        .setSmallIcon(R.drawable.ic_launcher)
        .setContentTitle("PushMessage"+caller_id)
        .setDefaults(Notification.DEFAULT_LIGHTS)
        .setOngoing(true) 
        .build();
		Compatibility.setNotificationLatestEventInfo(pushNoti, this, "PushMessage", caller_id, mNotifContentIntent);
		notifyWrapper(PUSH_ID,pushNoti);
	}
	
	public void setActivityToLaunchOnIncomingReceived(Class<? extends Activity> activity) {
		incomingReceivedActivity = activity;
		resetIntentLaunchedOnNotificationClick();
	}
	private void resetIntentLaunchedOnNotificationClick() {
		Intent notifIntent = new Intent(this, incomingReceivedActivity);
		mNotifContentIntent = PendingIntent.getActivity(this, 0, notifIntent, PendingIntent.FLAG_UPDATE_CURRENT);
		Compatibility.setNotificationLatestEventInfo(pushNoti, this, mNotificationTitle, "", mNotifContentIntent);
	}
	/**
	 * Wrap notifier to avoid setting the linphone icons while the service
	 * is stopping. When the (rare) bug is triggered, the linphone icon is
	 * present despite the service is not running. To trigger it one could
	 * stop linphone as soon as it is started. Transport configured with TLS.
	 */
	private synchronized void notifyWrapper(int id, Notification notification) {
		if (instance != null) {
			notificationManager.notify(id, notification);
		} else {
			Log.i("Service not ready, discarding notification");
		}
	}

	
	private void initButtons() {
		menu = (LinearLayout) findViewById(R.id.menu);
		menu1 = (LinearLayout) findViewById(R.id.menu1);
		mark = (LinearLayout) findViewById(R.id.mark);

		history = (RelativeLayout) findViewById(R.id.history);
		history.setOnClickListener(this);
		contacts = (RelativeLayout) findViewById(R.id.contacts);
		contacts.setOnClickListener(this);
		dialer = (RelativeLayout) findViewById(R.id.dialer);
		dialer.setOnClickListener(this);
		settings = (RelativeLayout) findViewById(R.id.settings);
		settings.setOnClickListener(this);
		chat = (RelativeLayout) findViewById(R.id.chat);
		chat.setOnClickListener(this);
		if (getResources().getBoolean(R.bool.replace_chat_by_about)) {
			chat.setVisibility(View.GONE);
			chat.setOnClickListener(null);
			findViewById(R.id.completeChat).setVisibility(View.GONE);
	
		}
		if (getResources().getBoolean(R.bool.replace_settings_by_about)) {
			settings.setVisibility(View.GONE);
			settings.setOnClickListener(null);
	
		}

		missedCalls = (TextView) findViewById(R.id.missedCalls);
		missedChats = (TextView) findViewById(R.id.missedChats);
	}
	
	private boolean isTablet() {
		return getResources().getBoolean(R.bool.isTablet);
	}

	private void hideStatusBar() {
		if (isTablet()) {
			return;
		}
		findViewById(R.id.fragmentContainer).setPadding(0, 0, 0, 0);
	}

	private void showStatusBar() {

	}


	public void changeCurrentFragmentans(FragmentsAvailable newFragmentType, Bundle extras) {
		changeCurrentFragment(newFragmentType, extras, false);
		if(FragmentsAvailable.HISTORY==newFragmentType)
		{
			LinphoneManager.getLc().resetMissedCallsCount();
			LinphoneActivity.instance().displayMissedCalls(0);
		}
	}

	
	
	private void changeCurrentFragment(FragmentsAvailable newFragmentType, Bundle extras) {
		changeCurrentFragment(newFragmentType, extras, false);
	}

	@SuppressWarnings("incomplete-switch")
	private void changeCurrentFragment(FragmentsAvailable newFragmentType, Bundle extras, boolean withoutAnimation) {
		if (newFragmentType == currentFragment && newFragmentType != FragmentsAvailable.CHAT) {
			return;
		}
		nextFragment = newFragmentType;

		if (currentFragment == FragmentsAvailable.DIALER) {
			try {
				dialerSavedState = getSupportFragmentManager().saveFragmentInstanceState(dialerFragment);
			} catch (Exception e) {
			}
		}

		Fragment newFragment = null;

		switch (newFragmentType) {
		case HISTORY:
			newFragment = new HistoryFragment();
			break;
		case HISTORY_DETAIL:
			//newFragment = new HistoryDetailFragment();
			newFragment = new NewHistoryDetailFragment();
			break;
		case CONTACTS:
			newFragment = new ContactsFragment();
			friendStatusListenerFragment = newFragment;
			break;
		case CONTACT:
			newFragment = new ContactFragment();
			break;
		case EDIT_CONTACT:
			newFragment = new EditContactFragment();
			break;
		case DIALER:
			newFragment = new DialerFragment();
			if (extras == null) {
				newFragment.setInitialSavedState(dialerSavedState);
			}
			dialerFragment = newFragment;
			break;
		case SETTINGS:
			newFragment = new SettingsFragment();
			break;
		case ACCOUNT_SETTINGS:
			newFragment = new AccountPreferencesFragment();
			break;
		case ABOUT:
		case ABOUT_INSTEAD_OF_CHAT:
		case ABOUT_INSTEAD_OF_SETTINGS:
			newFragment = new AboutFragment();
			break;
		case CHAT:
			newFragment = new ChatFragment();
			messageListenerFragment = newFragment;
			break;
		case CHATLIST:
			newFragment = new ChatListFragment();
			messageListFragment = new Fragment();
			break;
			
		case CHATNEW:
			hideMenu(true);
			TextView v=(TextView)findViewById(R.id.text);
			v.setText(R.string.NewChat);
			newFragment = new ChatFragmentNew();
			messageListenerFragment = newFragment;
			break;
		}

		if (newFragment != null) {
			newFragment.setArguments(extras);
			
			changeFragment(newFragment, newFragmentType, withoutAnimation);
						
		}
	}

	private void updateAnimationsState() {
		isAnimationDisabled = getResources().getBoolean(R.bool.disable_animations) || !LinphonePreferences.instance().areAnimationsEnabled();
		isContactPresenceDisabled = !getResources().getBoolean(R.bool.enable_linphone_friends);
	}

	public boolean isAnimationDisabled() {
		return isAnimationDisabled;
	}

	public boolean isContactPresenceDisabled() {
		return isContactPresenceDisabled;
	}

	private void changeFragment(Fragment newFragment, FragmentsAvailable newFragmentType, boolean withoutAnimation) {
		if (getResources().getBoolean(R.bool.show_statusbar_only_on_dialer)) {
			if (newFragmentType == FragmentsAvailable.DIALER) {
				
			} else {
				
			}
		}
		if (statusFragment != null) {
			statusFragment.closeStatusBar();
		}

		FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

		if (!withoutAnimation && !isAnimationDisabled && currentFragment.shouldAnimate()) {
			if (newFragmentType.isRightOf(currentFragment)) {
				transaction.setCustomAnimations(R.anim.slide_in_right_to_left,
						R.anim.slide_out_right_to_left,
						R.anim.slide_in_left_to_right,
						R.anim.slide_out_left_to_right);
			} else {
				transaction.setCustomAnimations(R.anim.slide_in_left_to_right,
						R.anim.slide_out_left_to_right,
						R.anim.slide_in_right_to_left,
						R.anim.slide_out_right_to_left);
			}
		}
		try {
			getSupportFragmentManager().popBackStackImmediate(newFragmentType.toString(), FragmentManager.POP_BACK_STACK_INCLUSIVE);
		} catch (java.lang.IllegalStateException e) {

		}

		transaction.addToBackStack(newFragmentType.toString());
		transaction.replace(R.id.fragmentContainer, newFragment, newFragmentType.toString());
		transaction.commitAllowingStateLoss();
		getSupportFragmentManager().executePendingTransactions();

		currentFragment = newFragmentType;
	}

	
	public void newdisplayHistoryDetail(String DisplayName){
		Bundle extras = new Bundle();
		extras.putString("DisplayName",DisplayName);
		changeCurrentFragment(FragmentsAvailable.HISTORY_DETAIL, extras);
		
	}	
	
	
	public void displayHistoryDetail(String sipUri, LinphoneCallLog log) {
		LinphoneAddress lAddress;
		try {
			lAddress = LinphoneCoreFactory.instance().createLinphoneAddress(sipUri);
		} catch (LinphoneCoreException e) {
			Log.e("Cannot display history details",e);
			return;
		}
		Uri uri = LinphoneUtils.findUriPictureOfContactAndSetDisplayName(lAddress, getContentResolver());

		String displayName = lAddress.getDisplayName();
		String pictureUri = uri == null ? null : uri.toString();

		String status;
		if (log.getDirection() == CallDirection.Outgoing) {
			status = "Outgoing";
		} else {
			if (log.getStatus() == CallStatus.Missed) {
				status = "Missed";
			} else {
				status = "Incoming";
			}
		}

		String callTime = secondsToDisplayableString(log.getCallDuration());
		String callDate = String.valueOf(log.getTimestamp());

			Bundle extras = new Bundle();
			extras.putString("SipUri", sipUri);
			if (displayName != null) {
				extras.putString("DisplayName", displayName);
				extras.putString("PictureUri", pictureUri);
			}
			extras.putString("CallStatus", status);
			extras.putString("CallTime", callTime);
			extras.putString("CallDate", callDate);

			changeCurrentFragment(FragmentsAvailable.HISTORY_DETAIL, extras);
		
	}

	@SuppressLint("SimpleDateFormat")
	private String secondsToDisplayableString(int secs) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		cal.set(0, 0, 0, 0, 0, secs);
		return dateFormat.format(cal.getTime());
	}

	public void displayContact(Contact contact, boolean chatOnly) {
	
			Bundle extras = new Bundle();
			extras.putSerializable("Contact", contact);
			extras.putBoolean("ChatAddressOnly", chatOnly);
			changeCurrentFragment(FragmentsAvailable.CONTACT, extras);
		
	}

	public void displayContacts(boolean chatOnly) {
	
		Bundle extras = new Bundle();
		extras.putBoolean("ChatAddressOnly", chatOnly);
		changeCurrentFragment(FragmentsAvailable.CONTACTS, extras);
		preferLinphoneContacts = false;
	}

	public void displayContactsForEdition(String sipAddress) {
		Bundle extras = new Bundle();
		extras.putBoolean("EditOnClick", true);
		extras.putString("SipAddress", sipAddress);
		changeCurrentFragment(FragmentsAvailable.CONTACTS, extras);
	}

	public void displayAbout() {
		changeCurrentFragment(FragmentsAvailable.ABOUT, null);
	}

	
	public void displayNewChat() {
		changeCurrentFragment(FragmentsAvailable.CHATNEW, null);
	}
	

	public void displayChat(String sipUri) {
		if (getResources().getBoolean(R.bool.disable_chat)) {
			return;
		}

		LinphoneAddress lAddress;
		try {
			lAddress = LinphoneCoreFactory.instance().createLinphoneAddress(sipUri);
		} catch (LinphoneCoreException e) {
			Log.e("Cannot display chat",e);
			return;
		}
		
		Uri uri = LinphoneUtils.findUriPictureOfContactAndSetDisplayName(lAddress, getContentResolver());
		String displayName = lAddress.getDisplayName();
		String pictureUri = uri == null ? null : uri.toString();

		if (currentFragment == FragmentsAvailable.CHATLIST || currentFragment == FragmentsAvailable.CHAT) {
				
				Bundle extras = new Bundle();
				extras.putString("SipUri", sipUri);
				if (lAddress.getDisplayName() != null) {
					extras.putString("DisplayName", displayName);
					extras.putString("PictureUri", pictureUri);
				}
				changeCurrentFragment(FragmentsAvailable.CHAT, extras);
		
		} else {
			changeCurrentFragment(FragmentsAvailable.CHATLIST, null);
			displayChat(sipUri);
		}
		LinphoneService.instance().resetMessageNotifCount();
		LinphoneService.instance().removeMessageNotification();
		displayMissedChats(getChatStorage().getUnreadMessageCount());
	}

	
	
	@Override
	public void onClick(View v) {
		int id = v.getId();
		resetSelection();

		if (id == R.id.history) {
			changeCurrentFragment(FragmentsAvailable.HISTORY, null);
			history.setSelected(true);
			LinphoneManager.getLc().resetMissedCallsCount();
			displayMissedCalls(0);
		} else if (id == R.id.contacts) {
			changeCurrentFragment(FragmentsAvailable.CONTACTS, null);
			contacts.setSelected(true);
		} else if (id == R.id.dialer) {
			changeCurrentFragment(FragmentsAvailable.DIALER, null);
			dialer.setSelected(true);
		} else if (id == R.id.settings) {
	
			changeCurrentFragment(FragmentsAvailable.SETTINGS, null);
			settings.setSelected(true);
		}else if (id == R.id.chat) {
			changeCurrentFragment(FragmentsAvailable.CHATLIST, null);
			chat.setSelected(true);
		}
	}

	private void resetSelection() {
		history.setSelected(false);
		contacts.setSelected(false);
		dialer.setSelected(false);
		settings.setSelected(false);
		chat.setSelected(false);

	}

	@SuppressWarnings("incomplete-switch")
	public void selectMenu(FragmentsAvailable menuToSelect) {
		currentFragment = menuToSelect;
		hideMenu(false); 
		hidemessage(false); 
		resetSelection();
  
		switch (menuToSelect) {
		case HISTORY:
			settings.setVisibility(View.GONE);  
			dialer.setSelected(true);
			break;
		case HISTORY_DETAIL:
			//Its for to show as dialer selected as History Option is buried under Dialer Layout
			dialer.setSelected(true);
			hideMenu(true); 
			break;
		case CONTACTS:
		case CONTACT:
		case EDIT_CONTACT:
			contacts.setSelected(true);
			break;
		case DIALER:
			dialer.setSelected(true);
			break;
		case SETTINGS:
		case ACCOUNT_SETTINGS:
			settings.setSelected(true);
			hideMenu(true);  
			hidemessage(true); 
			break;
		case ABOUT_INSTEAD_OF_CHAT:
		//	aboutChat.setSelected(true);
			break;
		case ABOUT_INSTEAD_OF_SETTINGS:
		//	aboutSettings.setSelected(true);
			break;
		case CHATNEW:
		case CHAT:
			
			chat.setSelected(true);
			hideMenu(true); 
			break;
		case CHATLIST:
			settings.setVisibility(View.GONE);  
			chat.setSelected(true);
			break;
		}
	}

	public void updateDialerFragment(DialerFragment fragment) {
		dialerFragment = fragment;
		// Hack to maintain soft input flags
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN | WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
	}

	public void updateChatFragment(ChatFragment fragment) {
		messageListenerFragment = fragment;
		// Hack to maintain soft input flags
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE | WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
	}

	public void updateChatListFragment(ChatListFragment fragment) {
		messageListFragment = fragment;
	}


	public void setmessage(String str){
		TextView v=(TextView)findViewById(R.id.text);
		v.setText(str);
	}
	
	public void hidemessage(boolean hide){
		settings.setVisibility(hide ? View.GONE : View.VISIBLE);
		TextView v=(TextView)findViewById(R.id.text);
		v.setText((hide ? R.string.button_setting : R.string.button_message));
	}
	
	public void hideMenu(boolean hide) {
		settings.setVisibility(hide ? View.GONE : View.VISIBLE);
		menu.setVisibility(hide ? View.GONE : View.VISIBLE);
		mark.setVisibility(hide ? View.GONE : View.VISIBLE);
	}

	public void updateStatusFragment(StatusFragment fragment) {
		statusFragment = fragment;

		LinphoneCore lc = LinphoneManager.getLcIfManagerNotDestroyedOrNull();
		if (lc != null && lc.getDefaultProxyConfig() != null) {
			statusFragment.registrationStateChanged(LinphoneManager.getLc().getDefaultProxyConfig().getState());
		}
	}

	public void displaySettings() {
		changeCurrentFragment(FragmentsAvailable.SETTINGS, null);
		settings.setSelected(true);
	}

	public void applyConfigChangesIfNeeded() {
		if (nextFragment != FragmentsAvailable.SETTINGS && nextFragment != FragmentsAvailable.ACCOUNT_SETTINGS) {
			updateAnimationsState();
		}
	}

	public void displayAccountSettings(int accountNumber) {
		Bundle bundle = new Bundle();
		bundle.putInt("Account", accountNumber);
		changeCurrentFragment(FragmentsAvailable.ACCOUNT_SETTINGS, bundle);
		settings.setSelected(true);
	}

	public StatusFragment getStatusFragment() {
		return statusFragment;
	}

	public List<String> getChatList() {
		return getChatStorage().getChatList();
	}

	public List<String> getDraftChatList() {
		return getChatStorage().getDrafts();
	}

	public List<ChatMessage> getChatMessages(String correspondent) {
		return getChatStorage().getMessages(correspondent);
	}

	public void removeFromChatList(String sipUri) {
		getChatStorage().removeDiscussion(sipUri);
	}

	public void removeFromDrafts(String sipUri) {
		getChatStorage().deleteDraft(sipUri);
	}

	@Override
	public void onMessageReceived(LinphoneAddress from, LinphoneChatMessage message, int id) {
		ChatFragment chatFragment = ((ChatFragment) messageListenerFragment);
		if (messageListenerFragment != null && messageListenerFragment.isVisible() && chatFragment.getSipUri().equals(from.asStringUriOnly())) {
			chatFragment.onMessageReceived(id, from, message);
			getChatStorage().markMessageAsRead(id);
		} else if (LinphoneService.isReady()) {
			displayMissedChats(getChatStorage().getUnreadMessageCount());
			if (messageListFragment != null && messageListFragment.isVisible()) {
				((ChatListFragment) messageListFragment).refresh();
			}
		}
	}

	public void updateMissedChatCount() {
		displayMissedChats(getChatStorage().getUnreadMessageCount());
	}

	public int onMessageSent(String to, String message) {
		getChatStorage().deleteDraft(to);
		return getChatStorage().saveTextMessage("", to, message, System.currentTimeMillis());
	}

	public int onMessageSent(String to, Bitmap image, String imageURL) {
		getChatStorage().deleteDraft(to);
		return getChatStorage().saveImageMessage("", to, image, imageURL, System.currentTimeMillis());
	}

	public void onMessageStateChanged(String to, String message, int newState) {
		getChatStorage().updateMessageStatus(to, message, newState);
	}

	public void onImageMessageStateChanged(String to, int id, int newState) {
		getChatStorage().updateMessageStatus(to, id, newState);
	}

	@Override
	public void onRegistrationStateChanged(RegistrationState state) {
		if (statusFragment != null) {
			LinphoneCore lc = LinphoneManager.getLcIfManagerNotDestroyedOrNull();
			if (lc != null && lc.getDefaultProxyConfig() != null)
				statusFragment.registrationStateChanged(lc.getDefaultProxyConfig().getState());
			else
				statusFragment.registrationStateChanged(RegistrationState.RegistrationNone);
		}
	}

	private void displayMissedCalls(final int missedCallsCount) {
		mHandler.post(new Runnable() {
			@Override
			public void run() {
				if (missedCallsCount > 0) {
					missedCalls.setText(missedCallsCount + "");
					missedCalls.setVisibility(View.VISIBLE);
					if (!isAnimationDisabled) {
						missedCalls.startAnimation(AnimationUtils.loadAnimation(LinphoneActivity.this, R.anim.bounce));
					}
				} else {
					missedCalls.clearAnimation();
					missedCalls.setVisibility(View.GONE);
				}
			}
		});
	}

	private void displayMissedChats(final int missedChatCount) {
		mHandler.post(new Runnable() {
			@Override
			public void run() {
				if (missedChatCount > 0) {
					missedChats.setText(missedChatCount + "");
					if (missedChatCount > 99) {
						missedChats.setTextSize(12);
					} else {
						missedChats.setTextSize(20);
					}
					missedChats.setVisibility(View.VISIBLE);
					if (!isAnimationDisabled) {
						missedChats.startAnimation(AnimationUtils.loadAnimation(LinphoneActivity.this, R.anim.bounce));
					}
				} else {
					missedChats.clearAnimation();
					missedChats.setVisibility(View.GONE);
				}
			}
		});
	}

	@Override
	public void onCallStateChanged(LinphoneCall call, State state, String message) {
		if (state == State.IncomingReceived) {
			startActivity(new Intent(this, IncomingCallActivity.class));
		} else if (state == State.OutgoingInit) {
			if (call.getCurrentParamsCopy().getVideoEnabled()) {
				startVideoActivity(call);
			} else {
				startIncallActivity(call);
			}
		} else if (state == State.CallEnd || state == State.Error || state == State.CallReleased) {
			// Convert LinphoneCore message for internalization
			if (message != null && message.equals("Call declined.")) { 
				displayCustomToast(getString(R.string.error_call_declined), Toast.LENGTH_LONG);
			} else if (message != null && message.equals("User not found.")) {
				displayCustomToast(getString(R.string.error_user_not_found), Toast.LENGTH_LONG);
			} else if (message != null && message.equals("Incompatible media parameters.")) {
				displayCustomToast(getString(R.string.error_incompatible_media), Toast.LENGTH_LONG);
			}
			resetClassicMenuLayoutAndGoBackToCallIfStillRunning();
		}

		int missedCalls = LinphoneManager.getLc().getMissedCallsCount();
		displayMissedCalls(missedCalls);
	}

	public void displayCustomToast(final String message, final int duration) {
		mHandler.post(new Runnable() {
			@Override
			public void run() {
				LayoutInflater inflater = getLayoutInflater();
				View layout = inflater.inflate(R.layout.toast, (ViewGroup) findViewById(R.id.toastRoot));

				TextView toastText = (TextView) layout.findViewById(R.id.toastMessage);
				toastText.setText(message);

				final Toast toast = new Toast(getApplicationContext());
				toast.setGravity(Gravity.CENTER, 0, 0);
				toast.setDuration(duration);
				toast.setView(layout);
				toast.show();
			}
		});
	}

	@Override
	public void setAddresGoToDialerAndCall(String number, String name, Uri photo) {

		AddressType address = new AddressText(this, null);
		address.setDisplayedName(name);
		address.setText(number);
		if (LinphoneManager.getLc().getCallsNb() == 0) {
			LinphoneManager.getInstance().newOutgoingCall(address);
		}
	}

	public void setAddressAndGoToDialer(String number) {
		Bundle extras = new Bundle();
		extras.putString("SipUri", number);
		changeCurrentFragment(FragmentsAvailable.DIALER, extras);
	}

	@Override
	public void goToDialer() {
		changeCurrentFragment(FragmentsAvailable.DIALER, null);
	}

	public void startVideoActivity(LinphoneCall currentCall) {
		Intent intent = new Intent(this, InCallActivity.class);
		intent.putExtra("VideoEnabled", true);
		startOrientationSensor();
		startActivityForResult(intent, callActivity);
	}

	public void startIncallActivity(LinphoneCall currentCall) {
		Intent intent = new Intent(this, InCallActivity.class);
		intent.putExtra("VideoEnabled", false);
		startOrientationSensor();
		startActivityForResult(intent, callActivity);
	}

	/**
	 * Register a sensor to track phoneOrientation changes
	 */
	private synchronized void startOrientationSensor() {
		if (mOrientationHelper == null) {
			mOrientationHelper = new LocalOrientationEventListener(this);
		}
		mOrientationHelper.enable();
	}

	private int mAlwaysChangingPhoneAngle = -1;
	private AcceptNewFriendDialog acceptNewFriendDialog;

	private class LocalOrientationEventListener extends OrientationEventListener {
		public LocalOrientationEventListener(Context context) {
			super(context);
		}

		@Override
		public void onOrientationChanged(final int o) {
			if (o == OrientationEventListener.ORIENTATION_UNKNOWN) {
				return;
			}

			int degrees = 270;
			if (o < 45 || o > 315)
				degrees = 0;
			else if (o < 135)
				degrees = 90;
			else if (o < 225)
				degrees = 180;

			if (mAlwaysChangingPhoneAngle == degrees) {
				return;
			}
			mAlwaysChangingPhoneAngle = degrees;

			Log.d("Phone orientation changed to ", degrees);
			int rotation = (360 - degrees) % 360;
			LinphoneCore lc = LinphoneManager.getLcIfManagerNotDestroyedOrNull();
			if (lc != null) {
				lc.setDeviceRotation(rotation);
				LinphoneCall currentCall = lc.getCurrentCall();
				if (currentCall != null && currentCall.cameraEnabled() && currentCall.getCurrentParamsCopy().getVideoEnabled()) {
					lc.updateCall(currentCall, null);
				}
			}
		}
	}

	public void showPreferenceErrorDialog(String message) {

	}

	public ArrayList<PeopleContact> getAllforChatContacts() {
		return contactArray;
	}

	
	public List<Contact> getAllContacts() {
		return contactList;
	}

	public List<Contact> getSIPContacts() {
		return sipContactList;
	}

	public Cursor getAllContactsCursor() {
		return contactCursor;
	}

	public Cursor getSIPContactsCursor() {
		return sipContactCursor;
	}

	public void setLinphoneContactsPrefered(boolean isPrefered) {
		preferLinphoneContacts = isPrefered;
	}

	public boolean isLinphoneContactsPrefered() {
		return preferLinphoneContacts;
	}

	private void refreshStatus(OnlineStatus status) {
		if (LinphoneManager.isInstanciated()) {
			LinphoneManager.getLcIfManagerNotDestroyedOrNull().setPresenceInfo(0, "", status);
		}
	}

	public void onNewSubscriptionRequestReceived(LinphoneFriend friend,
			String sipUri) {
		if (isContactPresenceDisabled) {
			return;
		}

		sipUri = sipUri.replace("<", "").replace(">", "");
		if (LinphonePreferences.instance().shouldAutomaticallyAcceptFriendsRequests()) {
			Contact contact = findContactWithSipAddress(sipUri);
			if (contact != null) {
				friend.enableSubscribes(true);
				try {
					LinphoneManager.getLc().addFriend(friend);
					contact.setFriend(friend);
				} catch (LinphoneCoreException e) {
					e.printStackTrace();
				}
			}
		} else {
			Contact contact = findContactWithSipAddress(sipUri);
			if (contact != null) {
				FragmentManager fm = getSupportFragmentManager();
				acceptNewFriendDialog = new AcceptNewFriendDialog(contact, sipUri);
				acceptNewFriendDialog.show(fm, "New Friend Request Dialog");
			}
		}
	}

	private Contact findContactWithSipAddress(String sipUri) {
		if (!sipUri.startsWith("sip:")) {
			sipUri = "sip:" + sipUri;
		}

		for (Contact contact : sipContactList) {
			for (String addr : contact.getNumerosOrAddresses()) {
				if (addr.equals(sipUri)) {
					return contact;
				}
			}
		}
		return null;
	}

	public void onNotifyPresenceReceived(LinphoneFriend friend) {
		if (!isContactPresenceDisabled && currentFragment == FragmentsAvailable.CONTACTS && friendStatusListenerFragment != null) {
			((ContactsFragment) friendStatusListenerFragment).invalidate();
		}
	}

	public boolean newFriend(Contact contact, String sipUri) {
		LinphoneFriend friend = LinphoneCoreFactory.instance().createLinphoneFriend(sipUri);
		friend.enableSubscribes(true);
		friend.setIncSubscribePolicy(LinphoneFriend.SubscribePolicy.SPAccept);
		try {
			LinphoneManager.getLc().addFriend(friend);
			contact.setFriend(friend);
			return true;
		} catch (LinphoneCoreException e) {
			e.printStackTrace();
		}
		return false;
	}

	private void acceptNewFriend(Contact contact, String sipUri, boolean accepted) {
		acceptNewFriendDialog.dismissAllowingStateLoss();
		if (accepted) {
			newFriend(contact, sipUri);
		}
	}

	public boolean removeFriend(Contact contact, String sipUri) {
		LinphoneFriend friend = LinphoneManager.getLc().findFriendByAddress(sipUri);
		if (friend != null) {
			friend.enableSubscribes(false);
			LinphoneManager.getLc().removeFriend(friend);
			contact.setFriend(null);
			return true;
		}
		return false;
	}

	private void searchFriendAndAddToContact(Contact contact) {
		if (contact == null || contact.getNumerosOrAddresses() == null) {
			return;
		}

		for (String sipUri : contact.getNumerosOrAddresses()) {
			if (LinphoneUtils.isSipAddress(sipUri)) {
				LinphoneFriend friend = LinphoneManager.getLc().findFriendByAddress(sipUri);
				if (friend != null) {
					friend.enableSubscribes(true);
					friend.setIncSubscribePolicy(LinphoneFriend.SubscribePolicy.SPAccept);
					contact.setFriend(friend);
					break;
				}
			}
		}
	}
	
	public void removeContactFromLists(Contact contact) {
		if (contactList.contains(contact)) {
			contactList.remove(contact);
			contactCursor = Compatibility.getContactsCursor(getContentResolver());
		}
		if (sipContactList.contains(contact)) {
			sipContactList.remove(contact);
			sipContactCursor = Compatibility.getSIPContactsCursor(getContentResolver());
		}
	}


	  
	public synchronized void prepareContactsnewInBackground() {
		
		
		contactArray= new ArrayList<PeopleContact>();
		
		Thread ContactsHandler = new Thread(new Runnable() {
			@Override
				public void run() {
					// TODO Auto-generated method stub
					readContactData();
				}
				
			});
			ContactsHandler.start();
			
		}
    
	    private void readContactData() {
	         
	        try {
	             
	            /*********** Reading Contacts Name And Number **********/
	           String phoneNumber = "";
	           ContentResolver cr = getBaseContext()
	                   .getContentResolver();
	           Cursor cur = cr
	                    .query(ContactsContract.Contacts.CONTENT_URI,
	                            null,
	                            null,
	                            null,
	                            null);
	             
	            // If data data found in contacts
	            if (cur.getCount() > 0) {
	                Log.i("AutocompleteContacts", "Reading   contacts........");
	                int k=0;
	                String name = "";
	                while (cur.moveToNext())
	                {
	                    String id = cur
	                            .getString(cur
	                                    .getColumnIndex(ContactsContract.Contacts._ID));
	                    name = cur
	                            .getString(cur
	                                    .getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
	                     
	                    //Check contact have phone number
	                    if (Integer
	                            .parseInt(cur
	                                    .getString(cur
	                                        .getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER))) > 0)
	                    {
	                             
	                        //Create query to get phone number by contact id
	                        Cursor pCur = cr
	                                    .query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
	                                            null,
	                                            ContactsContract.CommonDataKinds.Phone.CONTACT_ID
	                                                    + " = ?",
	                                            new String[] { id },
	                                            null);
	                            int j=0;
	                             
	                            while (pCur
	                                    .moveToNext())
	                            {
	                        
	                                    phoneNumber =""+pCur.getString(pCur
	                                                .getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
	                                    PeopleContact contact =new PeopleContact();
	                                    contact.setName(name.toString());
	                                    contact.setNumber(phoneNumber.toString());
	                                    contactArray.add(contact);
	                              
	                                    k++;
	                              
	                            }  // End while loop
	                            pCur.close();
	                        } // End if
	                     
	                }  // End while loop
	 
	            } // End Cursor value check
	            cur.close();
	        } catch (Exception e) {
	             Log.i("AutocompleteContacts","Exception : "+ e);
	        }
	   }

	
	public synchronized void prepareContactsInBackground() {
		if (contactCursor != null) {
			contactCursor.close();
		}
		if (sipContactCursor != null) {
			sipContactCursor.close();
		}

		contactCursor = Compatibility.getContactsCursor(getContentResolver());
		sipContactCursor = Compatibility.getSIPContactsCursor(getContentResolver());

		Thread sipContactsHandler = new Thread(new Runnable() {
			@Override
			public void run() {
				for (int i = 0; i < sipContactCursor.getCount(); i++) {
					Contact contact = Compatibility.getContact(getContentResolver(), sipContactCursor, i);
					if (contact == null)
						continue;
					
					contact.refresh(getContentResolver());
					if (!isContactPresenceDisabled) {
						searchFriendAndAddToContact(contact);
					}
					sipContactList.add(contact);
				}
				for (int i = 0; i < contactCursor.getCount(); i++) {
					Contact contact = Compatibility.getContact(getContentResolver(), contactCursor, i);
					if (contact == null)
						continue;
					
					for (Contact c : sipContactList) {
						if (c != null && c.getID().equals(contact.getID())) {
							contact = c;
							break;
						}
					}
					
					contactList.add(contact);
					
				}
			}
		});

		contactList = new ArrayList<Contact>();
		sipContactList = new ArrayList<Contact>();
		
		sipContactsHandler.start();
	}

	private void initInCallMenuLayout(boolean callTransfer) {
		selectMenu(FragmentsAvailable.DIALER);
		if (dialerFragment != null) {
			((DialerFragment) dialerFragment).resetLayout(callTransfer);
		}
	}

	public void resetClassicMenuLayoutAndGoBackToCallIfStillRunning() {
		mHandler.post(new Runnable() {
			@Override
			public void run() {
				if (dialerFragment != null) {
					((DialerFragment) dialerFragment).resetLayout(false);
				}

				if (LinphoneManager.isInstanciated() && LinphoneManager.getLc().getCallsNb() > 0) {
					LinphoneCall call = LinphoneManager.getLc().getCalls()[0];
					if (call.getState() == LinphoneCall.State.IncomingReceived) {
						startActivity(new Intent(LinphoneActivity.this, IncomingCallActivity.class));
					} else if (call.getCurrentParamsCopy().getVideoEnabled()) {
						startVideoActivity(call);
					} else {
						startIncallActivity(call);
					}
				}
			}
		});
	}

	public FragmentsAvailable getCurrentFragment() {
		return currentFragment;
	}

	public ChatStorage getChatStorage() {
		return ChatStorage.getInstance();
	}
	
	public void addContact(String displayName, String sipUri)
	{
		if (getResources().getBoolean(R.bool.use_android_native_contact_edit_interface)) {
			Intent intent = Compatibility.prepareAddContactIntent(displayName, sipUri);
			startActivity(intent);
		} else {
			Bundle extras = new Bundle();
			extras.putSerializable("NewSipAdress", sipUri);
			changeCurrentFragment(FragmentsAvailable.EDIT_CONTACT, extras);
		}
	}
	
	public void editContact(Contact contact)
	{
		if (getResources().getBoolean(R.bool.use_android_native_contact_edit_interface)) {
			Intent intent = Compatibility.prepareEditContactIntent(Integer.parseInt(contact.getID()));
			startActivity(intent);
		} else {
			Bundle extras = new Bundle();
			extras.putSerializable("Contact", contact);
			changeCurrentFragment(FragmentsAvailable.EDIT_CONTACT, extras);
		}
	}
	
	public void editContact(Contact contact, String sipAddress)
	{
		if (getResources().getBoolean(R.bool.use_android_native_contact_edit_interface)) {
			Intent intent = Compatibility.prepareEditContactIntentWithSipAddress(Integer.parseInt(contact.getID()), sipAddress);
			startActivity(intent);
		} else {
			Bundle extras = new Bundle();
			extras.putSerializable("Contact", contact);
			extras.putSerializable("NewSipAdress", sipAddress);
			changeCurrentFragment(FragmentsAvailable.EDIT_CONTACT, extras);
		}
	}

	public void exit() {
		finish();
		stopService(new Intent(ACTION_MAIN).setClass(this, LinphoneService.class));
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode == Activity.RESULT_FIRST_USER && requestCode == SETTINGS_ACTIVITY) {
			if (data.getExtras().getBoolean("Exit", false)) {
				exit();
			}else {
				FragmentsAvailable newFragment = (FragmentsAvailable) data.getExtras().getSerializable("FragmentToDisplay");
				changeCurrentFragment(newFragment, null, true);
				selectMenu(newFragment);
			}
		} else if (requestCode == callActivity) {
			boolean callTransfer = data == null ? false : data.getBooleanExtra("Transfer", false);
			boolean call_contact = data == null ? false : data.getBooleanExtra("recontact",true);
			if (LinphoneManager.getLc().getCallsNb() > 0) {
				if(call_contact){
					if (LinphoneActivity.isInstanciated()) {
						LinphoneActivity.instance().changeCurrentFragmentans(FragmentsAvailable.CONTACTS, null);
					}	
				}else{
				initInCallMenuLayout(callTransfer);
				}
			} else {
				resetClassicMenuLayoutAndGoBackToCallIfStillRunning();
			}
			
		} else {
			super.onActivityResult(requestCode, resultCode, data);
		}
	}

	@Override
	protected void onResume() {
		super.onResume();
	
	 	triggerPush();
		LinphoneManager.removeListener(this);
		LinphoneManager.addListener(this);
		prepareContactsInBackground();
		prepareContactsnewInBackground();
    	updateMissedChatCount();
		
		displayMissedCalls(LinphoneManager.getLc().getMissedCallsCount());

		if (LinphoneManager.getLc().getCalls().length > 0) {
			LinphoneCall call = LinphoneManager.getLc().getCalls()[0];
			LinphoneCall.State callState = call.getState();
			if (callState == State.IncomingReceived) {
				startActivity(new Intent(this, IncomingCallActivity.class));
			}
		}
		refreshStatus(OnlineStatus.Online);
	}
	
	public void ShowCallDialog(final String caller_id){
		LayoutInflater inflater = getLayoutInflater();
		View layout = inflater.inflate(R.layout.push_call, (ViewGroup) findViewById(R.id.toastRoot));
		final PopupWindow pmessagewindo = new PopupWindow(layout,575,LayoutParams.WRAP_CONTENT,true);
		pmessagewindo.showAtLocation(layout, Gravity.CENTER,0, 0);
		
		TextView toastText = (TextView) layout.findViewById(R.id.toastmessage);
		toastText.setText("Missed Call:"+caller_id);
		ImageView btnOk = (ImageView)layout.findViewById(R.id.pok);
		btnOk.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				pmessagewindo.dismiss();
				if(LinphoneActivity.isInstanciated()){
					
					try {
						LinphoneAddress address= LinphoneCoreFactory.instance().
								createLinphoneAddress(Utilites.getNumberInLinphoneFormat(caller_id));
						LinphoneActivity.instance().setAddresGoToDialerAndCall(address.asStringUriOnly(), address.getDisplayName(), null);
					} catch (LinphoneCoreException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}
				
			}
		});
		
		ImageView btnCal = (ImageView) layout.findViewById(R.id.pcancel);
		btnCal.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				pmessagewindo.dismiss();
			}
		});
		}
	
	public void DisplayMessageToChat(String caller_id,String body,String timeStamp){
		displayChat(Utilites.getNumberInLinphoneFormat(caller_id));
		try {
			LinphoneChatRoom chatRoom=null;
			LinphoneAddress from= LinphoneCoreFactory.instance().
					createLinphoneAddress(Utilites.getNumberInLinphoneFormat(caller_id));
		 //   LinphoneService.instance().displayMessageNotification(from.asStringUriOnly(),from.getDisplayName(),body);
			 LinphoneCore lc = LinphoneManager.getLcIfManagerNotDestroyedOrNull();
				if (lc != null) {
					Log.i("lc creates","lc creates");
					chatRoom = lc.getOrCreateChatRoom(Utilites.getNumberInLinphoneFormat(caller_id));
					//Only works if using liblinphone storage
					LinphoneActivity.instance().getChatStorage().markConversationAsRead(chatRoom);
				}
				
				boolean isNetworkReachable = lc == null ? false : lc.isNetworkReachable();
				
				if (chatRoom != null && body != null && body.length() > 0 && isNetworkReachable) {
					String messageToSend = body.toString();
					LinphoneChatMessage chatMessage = chatRoom.createLinphoneChatMessage(messageToSend);
				
					int newId = -1;
					if (messageToSend != null && messageToSend.length() > 0) {
			
					 newId = ChatStorage.getInstance().saveTextMessage(from.asStringUriOnly(), "", messageToSend, System.currentTimeMillis());
			
					}
					Log.i("--------LinphoneActivty--------------","----------------"+chatMessage.getTime());
					onMessageReceived(from,chatMessage,newId);
				} else if (!isNetworkReachable && LinphoneActivity.isInstanciated()) {
					LinphoneActivity.instance().displayCustomToast(getString(R.string.error_network_unreachable), Toast.LENGTH_LONG);
				}
			} catch (LinphoneCoreException e) {
				e.printStackTrace();
			}
	}
	
	@Override
	protected void onPause() {		
		super.onPause();
		refreshStatus(OnlineStatus.Away);
	}
	@Override
	protected void onStop(){
		super.onStop();
		}

	@Override
	protected void onDestroy() {
		LinphoneManager.removeListener(this);

		if (mOrientationHelper != null) {
			mOrientationHelper.disable();
			mOrientationHelper = null;
		}

		instance = null;
		super.onDestroy();

		unbindDrawables(findViewById(R.id.topLayout));
		System.gc();
	}

	private void unbindDrawables(View view) {
		if (view != null && view.getBackground() != null) {
			view.getBackground().setCallback(null);
		}
		if (view instanceof ViewGroup && !(view instanceof AdapterView)) {
			for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
				unbindDrawables(((ViewGroup) view).getChildAt(i));
			}
			((ViewGroup) view).removeAllViews();
		}
	}

	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		Bundle extras = intent.getExtras();
		if (extras != null && extras.getBoolean("GoToChat", false)) {
			LinphoneService.instance().removeMessageNotification();
			String sipUri = extras.getString("ChatContactSipUri");
			displayChat(sipUri);
		} else if (extras != null && extras.getBoolean("Notification", false)) {
			if (LinphoneManager.getLc().getCallsNb() > 0) {
				LinphoneCall call = LinphoneManager.getLc().getCalls()[0];
				if (call.getCurrentParamsCopy().getVideoEnabled()) {
					startVideoActivity(call);
				} else {
					startIncallActivity(call);
				}
			}
		} else if(extras != null && extras.getBoolean("PushNotification", false)){
			clearPushNotification();
			String caller_id=extras.getString("caller_id");
			String Message=extras.getString("Message");
			String timeStamp=extras.getString("timeStamp");
			DisplayMessageToChat(caller_id,Message,timeStamp);
		}else {
			if (dialerFragment != null) {
				((DialerFragment) dialerFragment).newOutgoingCall(intent);
			}
			if (LinphoneManager.getLc().getCalls().length > 0) {
				LinphoneCall calls[] = LinphoneManager.getLc().getCalls();
				if (calls.length > 0) {
					LinphoneCall call = calls[0];
					
					if (call != null && call.getState() != LinphoneCall.State.IncomingReceived) {
						if (call.getCurrentParamsCopy().getVideoEnabled()) {
							startVideoActivity(call);
						} else {
							startIncallActivity(call);
						}
					}
				}
				
				Collection<LinphoneCall.State> incoming = new ArrayList<LinphoneCall.State>();
				incoming.add(LinphoneCall.State.IncomingReceived);
				if (LinphoneUtils.getCallsInState(LinphoneManager.getLc(), incoming).size() > 0) {
					if (InCallActivity.isInstanciated()) {
						InCallActivity.instance().startIncomingCallActivity();
					} else {
						startActivity(new Intent(this, IncomingCallActivity.class));
					}
				}
			}
		}
	}
	public void clearPushNotification(){
	if(pushNoti!=null)
		notificationManager.cancel(PUSH_ID);
}

	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			if (currentFragment == FragmentsAvailable.DIALER) {
				boolean isBackgroundModeActive = LinphonePreferences.instance().isBackgroundModeEnabled();
				if (!isBackgroundModeActive) {
					stopService(new Intent(Intent.ACTION_MAIN).setClass(this, LinphoneService.class));
					finish();
				} else if (LinphoneUtils.onKeyBackGoHome(this, keyCode, event)) {
					return true;
				}
			} else {
			
				int backStackEntryCount = getSupportFragmentManager().getBackStackEntryCount();
				if (backStackEntryCount <= 1) {
					showStatusBar();
				}

				if (currentFragment == FragmentsAvailable.SETTINGS) {
					showStatusBar();
					updateAnimationsState();
				} else if (currentFragment == FragmentsAvailable.CHATLIST) {
					//Hack to ensure display the status bar on some devices
					showStatusBar();
				}
				
				

			}
		} else if (keyCode == KeyEvent.KEYCODE_MENU && statusFragment != null) {
			if (event.getRepeatCount() < 1) {
				statusFragment.openOrCloseStatusBar(true);
			}
		}
		return super.onKeyDown(keyCode, event);
	}

	@SuppressLint("ValidFragment")
	class AcceptNewFriendDialog extends DialogFragment {
		private Contact contact;
		private String sipUri;

		public AcceptNewFriendDialog(Contact c, String a) {
			contact = c;
			sipUri = a;
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
			View view = inflater.inflate(R.layout.new_friend_request_dialog, container);

			getDialog().setTitle(R.string.linphone_friend_new_request_title);

			Button yes = (Button) view.findViewById(R.id.yes);
			yes.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					acceptNewFriend(contact, sipUri, true);
				}
			});

			Button no = (Button) view.findViewById(R.id.no);
			no.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					acceptNewFriend(contact, sipUri, false);
				}
			});

			return view;
		}
	}

}

interface ContactPicked {
	void setAddresGoToDialerAndCall(String number, String name, Uri photo);
	void goToDialer();
}
