package org.linphone;
import org.linphone.mediastream.Log;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class KeepAliveHandler extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		Log.i("Keep alive handler invoked");
		if (LinphoneManager.getLcIfManagerNotDestroyedOrNull() != null) {
			//first refresh registers
			LinphoneManager.getLc().refreshRegisters();
			//make sure iterate will have enough time, device will not sleep until exit from this method
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				Log.e("Cannot sleep for 10s", e);
			}
			
		}

	}

}
